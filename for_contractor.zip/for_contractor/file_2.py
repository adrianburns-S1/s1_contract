# -*- coding: utf-8 -*-

import sys
import time
import multiprocessing

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import sunburnt
import pymongo
import MySQLdb
from redis import ConnectionPool as RedisPool, StrictRedis as Redis
from flask import g
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from elasticsearch import Elasticsearch
from elasticsearch.connection import create_ssl_context

from x1config import config

solr_connections = {}
redis_connection = {}
mysql_connection = None
mongo_connection = None
MYSQL_ENGINE_DICT = {}
SESSION_DICT = {}
ELASTIC_CONNECTION = None

read_only_mysql_connection = None
read_only_mongo_connection = None

MYSQL_URI = r'mysql://{user}:{password}@{mysql_uri}/{database}?charset=utf8'.format(user=config.get('sql', 'user'),
                                                                                    password=config.get('sql', 'password'),
                                                                                    mysql_uri=config.get('sql', 'url'),
                                                                                    database=config.get('sql', 'database'))


def check_mysql():
    global mysql_connection
    # if not mysql_connection:
    mysql_connection = MySQLdb.connect(host=config.get('sql', 'url'),
                                       db=config.get('sql', 'database'),
                                       user=config.get('sql', 'user'),
                                       passwd=config.get('sql', 'password'))
    mysql_connection.autocommit(True)


def mysql(query, values=None, commit=False, dictionary=True):
    global mysql_connection
    try:
        check_mysql()
        if not dictionary:
            cursor = mysql_connection.cursor()
        else:
            cursor = mysql_connection.cursor(MySQLdb.cursors.DictCursor)
    except:
        for i in range(3):
            try:
                check_mysql()
                if not dictionary:
                    cursor = mysql_connection.cursor()
                else:
                    cursor = mysql_connection.cursor(MySQLdb.cursors.DictCursor)
                    break
            except:
                print sys.exc_info()
                time.sleep(1)

    try:
        if values:
            i = 0
            while i < len(values):
                values[i] = MySQLdb.escape_string(str(values[i]))
                i += 1

            cursor.execute(query.format(*values))
        else:
            cursor.execute(query)
        if commit:
            mysql_connection.commit()
    except:
        cursor = None
    finally:
        return cursor


def solr(core=None):
    global solr_server
    global solr_connections

    if not core:
        connect_string = 'http://{host}:{port}/solr/{core}'.format(host=config.get('solr', 'url'),
                                                                   port=config.get('solr', 'port'),
                                                                   core=config.get('solr', 'core'))
    else:
        connect_string = 'http://{host}:{port}/solr/{core}'.format(host=config.get('solr', 'url'),
                                                                   port=config.get('solr', 'port'),
                                                                   core=core)

    try:
        return solr_connections[connect_string]
    except:
        solr_connections[connect_string] = sunburnt.SolrInterface(connect_string)
        return solr_connections[connect_string]


def redis(db=0):
    if db in redis_connection.keys():
        return redis_connection[db]
    pool = RedisPool(host=config.get('redis', 'url'), port=config.get('redis', 'port'), db=db)
    redis_connection[db] = Redis(connection_pool=pool)
    return redis_connection[db]


def mongo(read_only=False):
    if read_only or (hasattr(g, 'read_only') and g.read_only):
        global read_only_mongo_connection
        read_only_mongo_connection = mongo_get_connection(read_only_mongo_connection, config.get('read-only-dbs', 'mongo-database'),
                                                          config.get('read-only-dbs', 'mongo-host'),
                                                          config.getint('read-only-dbs', 'mongo-port'))
        connection = read_only_mongo_connection
    else:
        global mongo_connection
        mongo_connection = mongo_get_connection(mongo_connection, config.get('mongo', 'database'), config.get('mongo', 'url'),
                                                config.getint('mongo', 'port'))
        connection = mongo_connection
    return connection


def mongo_get_connection(connection, database, host, port):
    try:
        _ = connection.get_database(database).command('ping')
        return connection
    except:
        for _ in range(3):
            try:
                connection = pymongo.MongoClient(host=host, port=port)
                _ = connection.get_database(database).command('ping')
                break
            except pymongo.errors.AutoReconnect:
                print sys.exc_info()
                time.sleep(1)
    return connection


def mongo4email(connect=False):
    return pymongo.MongoClient(host=config.get('mongo4email', 'url'), port=config.getint('mongo4email', 'port'), connect=connect)


def mysql_engine(echo):
    global MYSQL_ENGINE_DICT
    mysql_engine = MYSQL_ENGINE_DICT.get(multiprocessing.current_process().pid)
    if mysql_engine:
        return mysql_engine
    mysql_engine = create_engine(MYSQL_URI,
                                 isolation_level=config.get('sqlalchemy', 'isolation_level'),
                                 pool_reset_on_return=config.get('sqlalchemy', 'pool_reset_on_return'),
                                 pool_recycle=config.getint('sqlalchemy', 'sqlalchemy_pool_recycle'),
                                 pool_size=config.getint('sqlalchemy', 'sqlalchemy_pool_size'),
                                 echo=echo)
    MYSQL_ENGINE_DICT[multiprocessing.current_process().pid] = mysql_engine
    return mysql_engine


def mysql_session(echo=False):
    global SESSION_DICT
    Session = SESSION_DICT.get(multiprocessing.current_process().pid)
    if Session:
        return Session()
    Session = scoped_session(
        sessionmaker(bind=mysql_engine(False),
                     autocommit=config.getboolean('sqlalchemy', 'autocommit'),
                     autoflush=config.getboolean('sqlalchemy', 'autoflush'),
                     expire_on_commit=config.getboolean('sqlalchemy', 'expire_on_commit')))
    SESSION_DICT[multiprocessing.current_process().pid] = Session
    return Session()


def elastic_search():
    global ELASTIC_CONNECTION
    if not ELASTIC_CONNECTION:
        ELASTIC_CONNECTION = Elasticsearch([config.get('elasticsearch', 'url')],
                                           http_auth=(config.get('elasticsearch', 'username'), config.get('elasticsearch', 'password')))
    return ELASTIC_CONNECTION
