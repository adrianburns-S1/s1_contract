"""Main x1 file."""
import sys
import os
import datetime
import re
import hashlib
import json
import time
try:
    import cPickle as pickle
except ImportError:
    import pickle
from random import shuffle
from itertools import chain
from urllib import unquote_plus as unescapeurl, urlopen
import warnings
from HTMLParser import HTMLParser
from operator import itemgetter
import subprocess
import base64
import string
from email.mime.text import MIMEText
from email.utils import formataddr
from email.header import Header
import ConfigParser
import copy
import logging
from cgi import escape as escapehtml
from sqlalchemy import desc, func

sys.path = [
    "/usr/local/websites/x1jobs", "/usr/local/websites/x1jobs/lib/python2.7/site-packages", "/usr/local/websites/x1jobs/sql-flask-eve",
    "/usr/local/websites/x1jobs/sql-flask-eve/helper_functions"
] + sys.path

try:
    import newrelic.agent
except ImportError:
    pass

from lxml.html.clean import clean_html
from lxml.etree import ParserError

import flask
from flask import Flask, request, session, render_template, send_from_directory, jsonify, redirect, abort, g, make_response, Response
from flask_login import login_user, logout_user, current_user, user_logged_in, user_logged_out, login_required, fresh_login_required
from flask_mongoengine import MongoEngine
from flask_security import Security, MongoEngineUserDatastore, RoleMixin, UserMixin
from flask_security.forms import RegisterForm, Required, StringField, LoginForm
from flask_security.utils import encrypt_password
from flask_security.signals import password_changed, password_reset
from flask.ext.security import user_registered
from flask_moment import Moment
from flask_cors import CORS, cross_origin
from flask_mail import Mail
from flask_images import Images
from flask_wtf.csrf import CsrfProtect

from eve import Eve
from eve.io.mongo import Validator

try:
    import xml.etree.cElementTree as ElementTree
except ImportError:
    import xml.etree.ElementTree as ElementTree

import requests
from bson.objectid import ObjectId
from bson.errors import InvalidDocument, InvalidId
from itsdangerous import TimedJSONWebSignatureSerializer, BadSignature, SignatureExpired, URLSafeTimedSerializer
from wtforms import BooleanField
from app.admin.one1 import one1
from app.alligator.alligator import alligator
from app.slackhandler.slackhandler import slackhandler
from app.blog.x1blog import x1blog
from app.job_fair_registration.job_fair_registration import job_fair_registration
from app.recruiters.post_a_job.post_a_job import post_a_job

import x1cursor

import x1utils
from x1utils import enabled_websites
import x1jobdetail
import x1searchresults
import x1vacancy
import x1cache
import x1jobsearchresultsetSQL
import x1jobsearchresultset
from x1config import config
import tables
from users import load_user, load_user_from_mongo, synchronise_user
from sqlutils import _check_or_create_company, _get_or_create, _get, send_paj_welcome_email, generate_etag, parse_paging_and_sorting_options, format_endpoint_output, get_surrounding_pages, update_md5_password, send_devs_email
import location_search
from blueprints.homepage_typeahead import get_location_typeahead, get_coreskill_specialism_typeahead, get_job_title_typeahead
from blueprints.api.file import file_get, file_search, file_patch, file_post
from blueprints.api.job.job_main import render_job_dict
from blueprints.third_party_posting import THIRD_PARTY_POSTING
from blueprints.api.user import send_welcome_email
from blueprints.cvdb import process_cv, delete_from_elastic, check_user_is_opted_in
from get_company_logo import get_company_logo
from pymongo import DESCENDING
from session import CustomSession
from pymongo import DESCENDING
warnings.filterwarnings('ignore', '^Unicode type received non-unicode bind param value')

JOB_POST_LOGGER = logging.getLogger('job_post')
FORMATTER = logging.Formatter(fmt='%(asctime)-15s %(levelname)s line %(lineno)d %(message)s', datefmt='%Y-%m-%dT%H:%M:%S')

HANDLER = logging.FileHandler(filename=config.get('job-post-logging', 'log_location'))
HANDLER.setFormatter(FORMATTER)
JOB_POST_LOGGER.addHandler(HANDLER)

try:
    LOG_LEVEL = getattr(logging, config.get('job-post-logging', 'log_level'))
    JOB_POST_LOGGER.setLevel(LOG_LEVEL)
except StandardError:
    JOB_POST_LOGGER.setLevel(logging.INFO)

sso_login_serializer = TimedJSONWebSignatureSerializer(config.get('app', 'secret_key'),
                                                       salt=config.get('security', 'security_remember_salt'),
                                                       expires_in=60 * 5)


def decrypt_token(token):
    return TimedJSONWebSignatureSerializer(app.config['SECRET_KEY']).loads(token)


def token_to_dict(token):
    if isinstance(token, dict):
        return token
    return decrypt_token(token)


def add_current_site_to_document(items):
    """Add the current site to any item"""
    for item in items:
        if isinstance(item, dict):
            item['saved_on'] = request.environ.get('x1sitename')


def get_remote_url_contents(items):
    """Get the data from filestack"""
    for idx, _ in enumerate(items):
        if isinstance(items[idx], dict):
            if 'remote_url' in items[idx] and items[idx]['remote_url'] and ('base64_data' not in items[idx] or
                                                                            not items[idx]['base64_data']):
                try:
                    if not items[idx]['remote_url'].startswith('https://cdn.filestackcontent.com/'):
                        raise RuntimeError('Illegal remote_url value {u}'.format(u=items[idx]['remote_url']))

                    items[idx]['base64_data'] = requests.get('{u}?base64encode=true'.format(u=items[idx]['remote_url']),
                                                             timeout=(6.05, 18)).content
                    items[idx]['remote_fetched'] = datetime.datetime.now()
                except StandardError:
                    items[idx]['base64_data_error'] = str(sys.exc_info())
        else:
            raise RuntimeError('Unexpected type {e}'.format(e=str(type(items[idx]))))


def _remove_p_tags(text):
    """
        clean_html will add <p> tags in certain circumstances,
        so we strip them back if they're added.
    """
    if text[:3] == '<p>' and text[-4:] == '</p>':
        return text[3:-4]
    return text


HTML_PARSER = HTMLParser()


def _flat_to_complex(item):
    objects = {}  # hash-based container for each object
    lists = {}  # hash-based container for each list

    for key, value in item.items():
        has_object_wildcard = re.search(r'^([^_]+)__', key, re.IGNORECASE)
        if has_object_wildcard:
            objects[has_object_wildcard.group(1)] = None
        elif re.search(r'&&', unicode(value)):
            lists[key] = unicode(value).split('&&')

    for list_name, this_list in lists.items():
        item[list_name] = this_list

    for obj_name in objects:

        this_obj = {}
        for key, value in item.items():
            if key.startswith('{s}__'.format(s=obj_name)):
                match = re.search(r'__(.+)$', key)
                this_obj[match.group(1)] = value
                del item[key]

        objects[obj_name] = this_obj

    for obj_name, this_obj in objects.items():
        item[obj_name] = this_obj

    return item


def flat_to_complex(items=None, _orig=None):
    """Takes a list of items from eve and transforms any string with __ in the middle to a dict"""
    if not items:
        return
    if isinstance(items, dict):
        items = _flat_to_complex(items)
    elif isinstance(items, list):
        for item in items:
            item = _flat_to_complex(item)


def add_user_info_to_document(items):
    """Add a user object to the item supplied"""
    for idx, _ in enumerate(items):
        if isinstance(items[idx], dict):
            try:
                items[idx]['session_id'] = session.get('_id')
            except KeyError:
                pass

            if current_user.is_authenticated:
                try:
                    user = x1_user_loader(current_user.id)
                    items[idx]['user'] = {
                        "id": str(user.get('_id')),
                        "id_object_id": user.get('_id'),
                        "email": str(user.get('email')),
                        "name": unicode(user.get('name'))
                    }

                    # top-level true key as well
                    items[idx]['uid_sha_{i}'.format(i=hashlib.sha1(str(user.get('_id'))).hexdigest())] = True
                except StandardError:
                    if x1utils.dev_server():
                        raise


def pre_get_my_account_resource(resource, _request, lookup):
    """Runs for each and every GET request.  Prevents users from returning another user's details"""

    if resource in ['user']:
        if _request.remote_addr not in config.get('misc', 'trusted_ip_addresses'):
            raise RuntimeError('unauthorised user lookup from {i}, not in {s}'.format(i=_request.remote_addr,
                                                                                      s=str(config.get('misc', 'trusted_ip_addresses'))))
        lookup["active"] = True

    # only return non-deleted documents which have a user structure matching this user
    if resource in ['File', 'Profile', 'ProfileExtra', 'CareerProfile', 'JobAlert']:

        try:
            lookup["user.id_object_id"] = str(current_user.id)
        except StandardError:
            abort(403, "FAIL: Anonymous user attempting to access a user-protected resource '{r}'".format(r=resource))

        lookup["$and"] = [{"deleted": {"$ne": True}}, {"deleted": {"$not": {"$type": "string"}}}]


def string_to_number(string_value):
    """Convert a string to either an int or float"""
    if isinstance(string_value, (float, int)):
        return string_value

    if '.' in string_value or ',' in string_value:
        try:
            return float(string_value)
        except ValueError:
            pass

    try:
        return int(string_value)
    except ValueError:
        return int(0)


def __allowed_newssitecontactdetail_fields():
    """
    Which fields to include on NewsSiteContactDetails records returned from the API.
    """
    return ['email', 'website', 'region']


def before_news_site_contact_detail(item):
    for key in [key for key in item if key not in __allowed_newssitecontactdetail_fields()]:
        del item[key]


def before_news_site_contact_details(resp):
    for item in resp['_items']:
        for key in [key for key in item if key not in __allowed_newssitecontactdetail_fields()]:
            del item[key]


def add_sql_file(_resource, payload):
    """Add a file to SQL when it's added to Mongo"""
    data = json.loads(payload.data)

    db_session = x1cursor.mysql_session()
    user = load_user(email_address=current_user.email, session=db_session, anonymous_allowed=True)
    live_status = db_session.query(tables.ProductStatus).filter_by(status="live").first()

    file_data = tables.MongoFile(_created=x1utils.convert_string_to_datetime(data['_created']),
                                 _updated=x1utils.convert_string_to_datetime(data['_updated']),
                                 _etag=data['_etag'],
                                 mongo_id=data['_id'],
                                 user_id=user.id,
                                 status_id=live_status.id)

    db_session.add(file_data)
    db_session.flush()
    return True


def patch_sql_file(_resource, payload):
    """Update the file in sql when it's updated in Mongo"""
    data = json.loads(payload.data)
    db_session = x1cursor.mysql_session()
    hidden_id = db_session.query(tables.ProductStatus).filter_by(status="hidden").first().id
    file_record = db_session.query(tables.MongoFile).filter_by(mongo_id=data['_id']).first()
    if file_record:
        file_record.status_id = hidden_id
        file_record._updated = datetime.datetime.now()
        db_session.flush()


def check_email_address(_request):
    data = _request.get_json(force=True, silent=True)
    if not x1utils.check_valid_email(data['email']):
        abort(422, "Not a valid email address")


try:
    MONGO_USERNAME = config.get('mongo', 'username'),
except ConfigParser.Error:
    MONGO_USERNAME = ''
try:
    MONGO_PASSWORD = config.get('mongo', 'password'),
except ConfigParser.Error:
    MONGO_PASSWORD = ''
EVE_SETTINGS = {
    'MONGO_HOST': config.get('mongo', 'url'),
    'MONGO_DBNAME': config.get('mongo', 'database'),
    'MONGO_PORT': config.get('mongo', 'port'),
    'MONGO_USERNAME': MONGO_USERNAME,
    'MONGO_PASSWORD': MONGO_PASSWORD,
    'ROMONGO_HOST': config.get('read-only-dbs', 'mongo-host'),
    'ROMONGO_DBNAME': config.get('read-only-dbs', 'mongo-database'),
    'ROMONGO_PORT': config.get('read-only-dbs', 'mongo-port'),
    'ROMONGO_USERNAME': MONGO_USERNAME,
    'ROMONGO_PASSWORD': MONGO_PASSWORD,
    'MONGO_QUERY_BLACKLIST': config.get('eve', 'mongo_query_blacklist'),
    'IF_MATCH': config.getboolean('eve', 'if_match'),
    'URL_PREFIX': config.get('eve', 'url_prefix'),
    'API_VERSION': config.get('eve', 'api_version'),
    'CACHE_CONTROL': config.get('eve', 'cache_control'),
    'CACHE_EXPIRES': config.getint('eve', 'cache_expires'),
    'RESOURCE_METHODS': config.get('eve', 'resource_methods'),
    'ITEM_METHODS': config.get('eve', 'item_methods'),
    'PAGINATION': config.getboolean('eve', 'pagination'),
    'PAGINATION_LIMIT': config.getint('eve', 'pagination_limit'),
    'PAGINATION_DEFAULT': config.getint('eve', 'pagination_default'),
    'DOMAIN': {
        'NewsSiteContactDetail': {
            'resource_methods': ['GET'],
            'item_methods': ['GET'],
            'allow_unknown': False,
            'schema': {
                'website': {
                    'type': 'string'
                },
                'region': {
                    'type': 'string'
                },
                'telephone': {
                    'type': 'string'
                },
                'email': {
                    'type': 'string'
                }
            },
        },
        'NewsSiteLocation': {
            'resource_methods': ['GET'],
            'item_methods': ['GET'],
            'allow_unknown': False,
            'schema': {
                'host': {
                    'type': 'string'
                },
                'loc_name': {
                    'type': 'string'
                },
                'loc_fullname': {
                    'type': 'string'
                },
                'x1_label': {
                    'type': 'string'
                },
            },
        },
        'Feed': {
            'allow_unknown': True,
            'resource_methods': ['GET', 'POST'],
            'item_methods': ['GET', 'PATCH', 'DELETE'],
            'schema': {
                'foo': {
                    'type': 'string'
                }
            },
        },
        'IrJob': {
            'allow_unknown': True,
            'resource_methods': ['GET', 'POST'],
            'item_methods': ['GET', 'PATCH', 'PUT'],
            'schema': {
                'foo': {
                    'type': 'string'
                }
            },
        },
        'SeoSchema': {
            'allow_unknown': True,
            'resource_methods': ['GET', 'POST'],
            'item_methods': ['GET', 'PATCH', 'PUT'],
            'schema': {
                'foo': {
                    'type': 'string'
                }
            },
        },
        'JobAlert': {
            'schema': {
                'email_frequency': {
                    'type': 'string',
                    'empty': False,
                    'required': True,
                },
                "Salary__BasePayL": {
                    'type': 'integer',
                    'coerce': string_to_number
                },
            },
            'allow_unknown': True,
        },
        'JobAlertSimple': {
            'schema': {
                'email_frequency': {
                    'type': 'string',
                    'empty': False,
                    'required': True,
                },
                'email': {
                    'type': 'string',
                    'empty': False,
                    'required': True,
                    'check_email_doesnt_exist_already': True
                },
                "Salary__BasePayL": {
                    'type': 'integer',
                    'coerce': string_to_number
                },
            },
            'allow_unknown': True,
        },
        'user': {
            'allow_unknown': False,
            'resource_methods': ['GET'],
            'item_methods': ['GET'],
            'schema': {
                'email': {
                    'type': 'string'
                },
                'name': {
                    'type': 'string'
                },
            },
        },
        'Profile': {
            'allow_unknown': True,
            'schema': {
                'thirdparty_optin': {
                    'type': 'string',
                    'required': False,
                    'allowed': ["no", "yes"],
                    'default': "no"
                },
                'marketing_optin': {
                    'type': 'string',
                    'required': False,
                    'allowed': ["no", "yes"],
                    'default': "no"
                },
                'cvdb_optin': {
                    'type': 'string',
                    'required': False,
                    'allowed': ["no", "yes"],
                    'default': "no"
                },
                'immediate_availability': {
                    'type': 'string',
                    'required': False,
                    'allowed': ["no", "yes"],
                    'default': "no"
                },
                'request_cvnow_review': {
                    'type': 'string',
                    'required': False,
                    'allowed': ["no", "yes"],
                    'default': "no"
                },
                'preferred_core_skills': {
                    'type': 'list',
                    'required': False,
                    'default': []
                },
                'saved_on': {
                    'type': 'string',
                    'required': False
                },
                'preferred_location': {
                    'type': 'string',
                    'required': False,
                    'default': ""
                },
                'session_id': {
                    'type': 'string',
                    'required': False
                }
            },
        },
        'CareerProfile': {
            'allow_unknown': True,
            'schema': {
                'foo': {
                    'type': 'string',
                    'required': False
                }
            },
        },
        'ProfileExtra': {
            'allow_unknown': True,
            'schema': {
                'job_started': {
                    "type": "datetime",
                    "coerce": x1utils.convert_string_to_datetime
                },
                'job_ended': {
                    "type": "datetime",
                    "coerce": x1utils.convert_string_to_datetime,
                    "required": False,
                    "nullable": True
                },
                'school_started': {
                    "type": "datetime",
                    "coerce": x1utils.convert_string_to_datetime
                },
                'school_ended': {
                    "type": "datetime",
                    "coerce": x1utils.convert_string_to_datetime,
                    "required": False,
                    "nullable": True
                },
                'still_working': {
                    'type': 'boolean',
                    'coerce': x1utils.coerce_to_bool,
                },
                'current_studies': {
                    'type': 'boolean',
                    'coerce': x1utils.coerce_to_bool,
                },
                'job_description': {
                    "type": 'string',
                    'required': False
                },
                'extra_type': {
                    "type": 'string',
                    'required': False
                },
                'saved_on': {
                    "type": 'string',
                    'required': False
                },
                'session_id': {
                    "type": 'string',
                    'required': False
                },
                'company_name': {
                    "type": 'string',
                    'required': False
                },
                'job_title': {
                    "type": 'string',
                    'required': False
                },
                'school': {
                    "type": 'string',
                    'required': False
                },
                'degree': {
                    "type": 'string',
                    'required': False
                },
                'grade': {
                    "type": 'string',
                    'required': False
                },
                'subject': {
                    "type": 'string',
                    'required': False
                }
            },
        },
        'CVReviewRequests': {
            'allow_unknown': True,
            'resource_methods': ['GET'],
            'item_methods': ['GET'],
        },
        'JobFairRegistrations': {
            'allow_unknown': True,
            'resource_methods': ['GET', 'POST'],
            'item_methods': ['GET', 'PATCH', 'DELETE'],
        },
        'SiteFeatures': {
            'allow_unknown': True,
            'resource_methods': ['GET', 'POST'],
            'item_methods': ['GET', 'PATCH', 'DELETE'],
        },
        'Skill': {
            'resource_methods': ['GET'],
            'item_methods': ['GET'],
            'schema': {
                'core_skill': {
                    'type': 'string',
                    'required': True,
                    'empty': False
                },
                'specialism': {
                    'type': 'string'
                },
            },
        },
    },
}


class MyEveValidators(Validator):
    """Eve validators"""

    def _validate_compare_token_user_id(self, check_token_file_upload, field, token):

        if check_token_file_upload:
            if isinstance(token, dict):
                data = token
            else:
                try:
                    data = decrypt_token(token)
                except SignatureExpired:
                    self._error(field, "Signature expired ({e})".format(e=str(sys.exc_info())))
                except BadSignature:
                    self._error(field, "Bad signature from {e}".format(e=token))
                except StandardError:
                    raise RuntimeError
            if current_user.is_anonymous:
                pass
            else:
                if data['user_id'] == current_user.id:
                    self._error(field, "Token is for user other than the current user")

    def _validate_any_of_required(self, any_of_required, _field, _value):
        if any_of_required:
            try:
                original_doc = self._original_document
            except StandardError:
                original_doc = {}

            doc = self.document
            for required_field in any_of_required:
                try:
                    if all([required_field in doc, doc.get(required_field, None) is not None]):
                        return True
                    elif all([required_field in original_doc and original_doc.get(required_field, None) is not None]):
                        return True
                except StandardError:
                    continue
            self._error(None, "One of {required_fields} must be set".format(required_fields=any_of_required))

    def _validate_check_email_doesnt_exist_already(self, check, field, _value):
        """Check if an email address already exists"""
        if check:
            if current_user.is_authenticated:
                self._error(field, "This user is already logged in.")
            else:
                doc = self.document
                email_address = doc.get('email')
                if email_address:
                    test_user = DBM.get_collection('user').find({"email": email_address, "active": True}).count()
                    if test_user:
                        self._error(field, 'This user already has an account')


TMPL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'DOCUMENT_ROOT')

app = Eve(__name__, template_folder=TMPL_DIR, settings=EVE_SETTINGS, validator=MyEveValidators)
app.on_insert_JobAlert += add_user_info_to_document
app.on_insert_Profile += add_user_info_to_document
app.on_insert_Profile += add_current_site_to_document
app.on_insert_CareerProfile += add_user_info_to_document
app.on_insert_CareerProfile += add_current_site_to_document
app.on_insert_ProfileExtra += add_user_info_to_document
app.on_insert_ProfileExtra += add_current_site_to_document
app.on_insert_JobAlert += add_current_site_to_document
app.on_insert_JobAlertSimple += add_current_site_to_document
app.on_pre_GET += pre_get_my_account_resource
app.on_insert_JobAlert += flat_to_complex
app.on_update_JobAlert += flat_to_complex
app.on_insert_JobAlertSimple += flat_to_complex
app.on_pre_POST_JobAlertSimple += check_email_address
app.on_update_JobAlertSimple += flat_to_complex
app.on_insert_Feed += flat_to_complex
app.on_update_Feed += flat_to_complex
app.on_fetched_item_NewsSiteContactDetail += before_news_site_contact_detail
app.on_fetched_resource_NewsSiteContactDetail += before_news_site_contact_details


def regex_replace(value, find, replace):
    return re.sub(find, replace, value)


def date2seconds(date_value=None, mformat="%Y-%m-%d"):
    """Add a Jinja filter to convert a date to seconds"""
    if date_value is None:
        date_value = datetime.datetime.today().strftime(mformat)
    if isinstance(date_value, basestring):
        date_value = x1utils.convert_string_to_datetime(date_value)
    try:
        return int(time.mktime(date_value.timetuple()))
    except StandardError:
        return 0


app.jinja_env.filters['date2seconds'] = date2seconds
app.jinja_env.filters['regex_replace'] = regex_replace
app.jinja_env.add_extension('jinja2.ext.do')


@app.context_processor
def inject_dev_variable():
    return dict(is_dev=x1utils.dev_server())


@app.context_processor
def inject_staging_variable():
    return dict(is_staging=x1utils.is_staging())


@app.context_processor
def inject_current_time():
    return dict(current_time=int(time.mktime(datetime.date.today().timetuple())))


app.config['DEBUG'] = config.getboolean('app', 'debug')
app.config['TESTING'] = config.getboolean('app', 'testing')
app.config['TRAP_HTTP_EXCEPTIONS'] = config.getboolean('app', 'trap_http_exceptions')
app.config['SECRET_KEY'] = config.get('app', 'secret_key')

app.url_map.converters['regex'] = x1utils.RegexConverter

app.register_blueprint(one1, url_prefix=config.get('blueprints', 'one1_url'))
app.register_blueprint(alligator, url_prefix=config.get('blueprints', 'alligator_url'))
app.register_blueprint(x1blog, url_prefix=config.get('blueprints', 'blog_url'))
app.register_blueprint(job_fair_registration, url_prefix=config.get('blueprints', 'job_fair_registration_url'))
app.register_blueprint(post_a_job, url_prefix=config.get('blueprints', 'post_a_job_url'))
app.register_blueprint(slackhandler, url_prefix='/x1')
app.register_blueprint(THIRD_PARTY_POSTING, url_prefix=config.get('blueprints', 'broadbean_post_url'))
app.register_blueprint(THIRD_PARTY_POSTING, url_prefix=config.get('blueprints', 'idibu_post_url'))
app.register_blueprint(THIRD_PARTY_POSTING, url_prefix=config.get('blueprints', 'threepp_post_url'))

app.config['MAIL_SERVER'] = config.get('mail', 'mail_server')
app.config['MAIL_PORT'] = config.getint('mail', 'mail_port')
if config.get('mail', 'mail_username') and config.get('mail', 'mail_username') != "''":
    app.config['MAIL_USERNAME'] = config.get('mail', 'mail_username')
    try:
        app.config['MAIL_PASSWORD'] = config.get('mail', 'mail_password')
    except KeyError:
        if config.getboolean('mail', 'mail_required_on_dev'):
            raise
        else:
            app.config['MAIL_FAIL_ON_DEV'] = str(sys.exc_info())

if x1utils.dev_server():
    app.config['MAIL_USE_TLS'] = config.getboolean('mail', 'mail_use_tls')
    app.config['MAIL_USE_SSL'] = config.getboolean('mail', 'mail_use_ssl')

app.config['MAIL_DEBUG'] = config.getboolean('mail', 'mail_debug')
app.config['JSONIFY_PRETTYPRINT_REGULAR'] = config.getboolean('app', 'jsonify_prettyprint_regular')

app.config['LOGIN_DISABLED'] = config.getboolean('security', 'login_disabled')
#
app.config['SESSION_TYPE'] = config.get('session', 'session_type')
app.config['SESSION_REDIS'] = x1cursor.redis()
app.config['SESSION_PERMANENT'] = config.getboolean('session', 'session_permanent')
app.config['SESSION_USE_SIGNER'] = config.getboolean('session', 'session_use_signer')
app.config['SESSION_KEY_PREFIX'] = config.get('session', 'session_key_prefix')
app.config['SESSION_COOKIE_SECURE'] = config.getboolean('session', 'session_cookie_secure')
app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(config.getint('session', 'permanent_session_lifetime'))
#
app.config['SECURITY_TRACKABLE'] = config.getboolean('security', 'security_trackable')
app.config['SECURITY_REGISTERABLE'] = config.getboolean('security', 'security_registerable')
app.config['SECURITY_RECOVERABLE'] = config.getboolean('security', 'security_recoverable')
app.config['SECURITY_CHANGEABLE'] = config.getboolean('security', 'security_changeable')
app.config['SECURITY_CHANGE_URL'] = config.get('security', 'security_change_url')
app.config['SECURITY_POST_CHANGE_VIEW'] = config.get('security', 'security_post_change_view')
app.config['SECURITY_DEFAULT_REMEMBER_ME'] = config.getboolean('security', 'security_default_remember_me')
app.config['SECURITY_REMEMBER_SALT'] = config.get('security', 'security_remember_salt')
app.config['DEFAULT_SECURITY_EMAIL_SENDER'] = config.get('security', 'default_security_email_sender')
app.config['SECURITY_EMAIL_SENDER'] = config.get('security', 'security_email_sender')
app.config['SECURITY_EMAIL_SUBJECT_REGISTER'] = config.get('security', 'security_email_subject_register')
app.config['SECURITY_LOGIN_URL'] = config.get('security', 'security_login_url')
app.config['SECURITY_LOGOUT_URL'] = config.get('security', 'security_logout_url')
app.config['SECURITY_REGISTER_URL'] = config.get('security', 'security_register_url')
app.config['SECURITY_POST_REGISTER_VIEW'] = config.get('security', 'security_post_register_view')
app.config['SECURITY_PASSWORD_HASH'] = config.get('security', 'security_password_hash')
app.config['SECURITY_PASSWORD_SALT'] = config.get('security', 'security_password_salt')
app.config['SECURITY_SEND_PASSWORD_CHANGE_EMAIL'] = config.getboolean('security', 'security_send_password_change_email')
app.config['SECURITY_SEND_PASSWORD_RESET_NOTICE_EMAIL'] = config.getboolean('security', 'security_send_password_reset_notice_email')
app.config['REDIS_HOST'] = config.get('redis', 'url')
app.config['SOLR_HOST'] = config.get('solr', 'url')
app.config['REMEMBER_COOKIE_DURATION'] = datetime.timedelta(config.getint('session', 'remember_cookie_duration'))
app.config['SITEMAPS_DIRECTORY'] = config.get('x1portal', 'sitemaps_location')

LOGIN_SERIALIZER = URLSafeTimedSerializer(app.secret_key, salt=app.config['SECURITY_REMEMBER_SALT'])

app.config.from_object(__name__)

if x1utils.dev_server():
    CORS = CORS(app, supports_credentials=True)
else:
    CORS = CORS(app,
                resources={
                    r'/api/v1/*': {
                        "origins": "*"
                    },
                    r'/nto': {
                        "origins": "*"
                    },
                    r'/nfj': {
                        "origins": "*"
                    },
                    r'/nto/': {
                        "origins": "*"
                    },
                    r'/nfj/': {
                        "origins": "*"
                    },
                })
IMAGES = Images(app)

CustomSession(app)

if config.getboolean('misc', 'user_database_mongodb'):

    app.config['MONGODB_DB'] = config.get('mongo', 'database')
    app.config['MONGODB_HOST'] = config.get('mongo', 'url')

    DB = MongoEngine(app)

    class Role(DB.Document, RoleMixin):
        name = DB.StringField(max_length=80, unique=True, required=True)
        description = DB.StringField(max_length=255)

    class User(DB.Document, UserMixin):
        """Class to represent a logged in user"""
        email = DB.EmailField(max_length=255, unique=True)
        name = DB.StringField(max_length=255)
        password = DB.StringField(max_length=255)
        active = DB.BooleanField(default=True)
        created_at = DB.DateTimeField(default=datetime.datetime.now)
        confirmed_at = DB.DateTimeField()
        activated_at = DB.DateTimeField()
        deleted_at = DB.DateTimeField()
        activated_at = DB.DateTimeField()
        roles = DB.ListField(DB.ReferenceField(Role), default=['JobSeeker'])
        saved_on = DB.StringField(max_length=7)
        # Do not create indexes if they do not already exist
        # Note that this will have the effect of not enforcing
        # the unique constraint unless a unique index is created
        # in Mongo by hand.
        meta = {'auto_create_index': False}

        last_login_at = DB.DateTimeField()
        current_login_at = DB.DateTimeField()
        last_login_ip = DB.StringField(max_length=16)
        current_login_ip = DB.StringField(max_length=16)
        login_count = DB.IntField()

        def __init__(self, **kwargs):
            #  This key was added for the cn migration, but breaks the creation of the user object
            if 'cn_user_id' in kwargs:
                del kwargs['cn_user_id']
            kwargs['saved_on'] = request.environ['x1sitename']
            super(User, self).__init__(**kwargs)

        def get(self, key, default=None):
            if hasattr(self, key):
                return getattr(self, key)
            return default

        @staticmethod
        def is_in_cvdb():
            return False

        @staticmethod
        def has_applied():
            return False

        @staticmethod
        def has_cv():
            return False

        @staticmethod
        def is_ops():
            return False

        def user_opt_in_CVDB(self):
            session = x1cursor.mysql_session()
            try:
                live_status = _get(tables.ProductStatus, session, status='live')
                user = _get(tables.User, session=session, email=self.email, cacheable=False)
                if user == None:
                    raise StandardError("User Sync Error Between Mongo and MySQL")
                query = session.query(tables.Files)
                query = query.filter_by(user_id=user.id, default_cv=1, status_id=live_status.id)
                try:
                    if query.first():
                        return True
                    return False
                except StandardError:
                    return False
            except StandardError:
                return False

        def user_number_of_alerts(self):
            session = x1cursor.mysql_session()
            user = _get(tables.User, session=session, email=self.email, cacheable=False)
            alerts_sql = session.query(tables.JobAlert).filter_by(user_id=user.id, _deleted=None).count()
            return (alerts_sql)

        def user_total_cvs_uploaded(self):
            session = x1cursor.mysql_session()
            live_status = _get(tables.ProductStatus, session, status='live')
            try:
                user = _get(tables.User, session=session, email=self.email, cacheable=False)
                if user == None:
                    raise StandardError("User Sync Error Between Mongo and MySQL")
                else:
                    query = session.query(tables.Files)
                    query = query.filter_by(user_id=user.id, status_id=live_status.id)
                    count = 0

                    if query.all():
                        count = query.count()
                        return count
            except StandardError:
                return 0

        def user_has_career_profile(self):
            session = x1cursor.mysql_session()
            live_status = _get(tables.ProductStatus, session, status='live')
            try:
                user = _get(tables.User, session=session, email=self.email, cacheable=False)
                if user == None:
                    raise StandardError("User Sync Error Between Mongo and MySQL")
                query = session.query(tables.Files)
                query = query.filter_by(user_id=user.id, career_profile_cv=1, status_id=live_status.id)
                try:
                    if query.first():
                        return True
                    return False
                except StandardError:
                    return False
            except StandardError:
                return False

        def user_number_jobs_application_history(self):
            session = x1cursor.mysql_session()
            try:
                user = _get(tables.User, session=session, email=self.email, cacheable=False)
                if user == None:
                    raise StandardError("User Sync Error Between Mongo and MySQL")
                query = session.query(tables.JobApplication)
                query = query.filter_by(user_id=user.id)
                count = 0
                try:
                    if query.all():
                        count = query.count()
                    return count
                except StandardError:
                    return False
            except StandardError:
                return False

        def user_can_start_immediately(self):
            mongo_db = x1cursor.mongo().get_database('any1jobs')
            profile_collection = mongo_db.get_collection('Profile')
            try:
                profile = profile_collection.find_one({"user.email": re.compile(self.email, re.IGNORECASE)})
                if profile['immediate_availability'] == 'yes':
                    return True
                return False
            except StandardError:
                return False

        def user_last_CV_upload_date(self):
            try:
                session = x1cursor.mysql_session()
                live_status = _get(tables.ProductStatus, session, status='live')
                user = _get(tables.User, session=session, email=self.email, cacheable=False)
                if user == None:
                    raise StandardError("User Sync Error Between Mongo and MySQL")
                query = session.query(tables.Files)
                query = query.filter_by(user_id=user.id, status_id=live_status.id)
                query = query.order_by(desc(tables.Files._created))
                try:
                    if query.first():
                        return query.first()._created
                    return False
                except StandardError:
                    return False
            except StandardError:
                return False

        def user_last_saved_job_date(self):
            session = x1cursor.mysql_session()
            user = _get(tables.User, session=session, email=self.email, cacheable=False)
            if user == None:
                raise StandardError("User Sync Error Between Mongo and MySQL")
            query = session.query(tables.UserStoredJob)
            query = query.filter_by(user_id=user.id, status='live')
            query = query.order_by(desc(tables.UserStoredJob._updated))
            query = query.first()
            try:
                if query:
                    return query._updated
                else:
                    return False
            except StandardError:
                return False

        def user_number_of_saved_jobs(self):
            session = x1cursor.mysql_session()
            user = _get(tables.User, session=session, email=self.email, cacheable=False)
            if user == None:
                raise StandardError("User Sync Error Between Mongo and MySQL")
            query = session.query(tables.UserStoredJob)
            count = query.filter_by(user_id=user.id, status='live').count()
            try:
                return count
            except StandardError:
                return False

        def user_searches_performed_this_session(self):
            try:
                return session['search_count']
            except KeyError:
                return 0

        def user_number_of_applications_today(self):
            session = x1cursor.mysql_session()
            try:
                user = _get(tables.User, session=session, email=self.email, cacheable=False)
                if user == None:
                    raise StandardError("User Sync Error Between Mongo and MySQL")
                query = session.query(tables.JobApplication)
                query = query.filter_by(user_id=user.id)
                YESTERDAY_DATE = datetime.datetime.now() - datetime.timedelta(days=1)
                count = 0
                try:
                    for row in query.all():
                        if row._created > YESTERDAY_DATE:
                            count += 1
                    return count
                except StandardError:
                    return False
            except StandardError:
                return False

        def user_last_core_skill_specified(self):
            try:
                return session['user_last_core_skill_specified']
            except KeyError:
                return False

        def user_last_internal_application_date(self):
            session = x1cursor.mysql_session()
            try:
                user = _get(tables.User, session=session, email=self.email, cacheable=False)
                if user == None:
                    raise StandardError("User Sync Error Between Mongo and MySQL")
                this_job_from = _get(tables.ThisJobFrom, session=session, this_job_from='jobsmanager', cacheable=False)
                query = session.query(tables.JobApplication)
                query = query.filter_by(user_id=user.id)
                query = query.join(tables.JobApplication.job)
                query = query.filter(tables.Job.this_job_from_id == this_job_from.id)
                query = query.order_by(desc(tables.JobApplication._created))
                try:
                    if query.first():
                        return query.first()._created
                    return False
                except StandardError:
                    return False
            except StandardError:
                return False

        def user_last_external_application_date(self):
            session = x1cursor.mysql_session()
            try:
                user = _get(tables.User, session=session, email=self.email, cacheable=False)
                if user == None:
                    raise StandardError("User Sync Error Between Mongo and MySQL")
                this_job_from = _get(tables.ThisJobFrom, session=session, this_job_from='jobsmanager', cacheable=False)
                query = session.query(tables.JobApplication)
                query = query.filter_by(user_id=user.id)
                query = query.join(tables.JobApplication.job)
                query = query.filter(tables.Job.this_job_from_id != this_job_from.id)
                query = query.order_by(desc(tables.JobApplication._created))
                try:
                    if query.first():
                        return query.first()._created
                    return False
                except StandardError:
                    return False
            except StandardError:
                return False

        def md5(self, what=None):
            if what is None:
                what = self.email
            return x1utils.md5(what)

        def email_sha1(self, what=None):
            if what is None:
                what = self.email
            return x1utils.sha1(what)

        def email_sha256(self, what=None):
            if what is None:
                what = self.email
            return x1utils.sha256(what)

        def first_name(self):
            try:
                return re.sub(r' .+$', '', self.name)
            except StandardError:
                return self.name


MOMENT = Moment(app)
EMAIL = Mail(app)
DBM = x1cursor.mongo().get_database('any1jobs')

app.config['WTF_CSRF_CHECK_DEFAULT'] = config.getboolean('misc', 'wtf_csrf_check_default')
CSRF = CsrfProtect(app)


def x1_user_loader(user_id=None, email_address=None, load_cvs=True, session=None):
    """Load a user from Mongo by user_id or email address"""

    user = None

    if isinstance(user_id, basestring):
        user_id = ObjectId(user_id)

    if user_id or email_address:
        users_collection = DBM.get_collection('user')
        if user_id:
            user_cursor = users_collection.find({"_id": user_id})
            if user_cursor.count():
                user = user_cursor.next()
        elif email_address:
            user_cursor = users_collection.find({"email": re.compile('^{email}$'.format(email=email_address), re.IGNORECASE)})
            if user_cursor.count():
                user = user_cursor.next()

    if user and load_cvs:
        try:
            if not session:
                session = x1cursor.mysql_session()
            sql_user = load_user(_id=str(user_id), session=session)
            query = session.query(tables.Files)
            query = query.join(tables.Files.user)
            query = query.filter_by(id=sql_user.id)
            query = query.join(tables.Files.status)
            query = query.filter_by(status='live')
            for cvfile in query.all():
                cvfile = map_file_get(cvfile.to_dict())
                try:
                    user['cvs'].append(cvfile)
                except StandardError:
                    user['cvs'] = [cvfile]
        except StandardError:
            pass

    return user


def generate_auth_token(user=None, params=None, expires=7200, include_session=True):
    """Return an auth token for a user"""

    if not params:
        params = {}

    try:
        user_id = user.id
    except AttributeError:
        if isinstance(user, dict):
            if 'id' in user:
                user_id = user['id']
            elif '_id' in user:
                user_id = user['_id']
            else:
                user_id = 'fail'
        else:
            # anonymous user
            user_id = 'Not signed in'

    return_object = {'user_id': str(user_id), 'params': params, '_created': datetime.datetime.now().isoformat()}

    if include_session:
        try:
            return_object['session_id'] = session.get('_id')
        except StandardError:
            pass

    return TimedJSONWebSignatureSerializer(app.config['SECRET_KEY'], expires_in=expires).dumps(return_object)


@app.errorhandler(404)
def page_not_found(e):
    return render_template('error404.html'), 404


@app.errorhandler(502)
def server_error(e):
    return render_template('error_502_nginx.html'), 502


class _MongoEngineUserDatastore(MongoEngineUserDatastore):

    def find_user(self, **kwargs):
        try:
            int(kwargs['id'])
        except ValueError:
            pass
        else:
            user_query = r"""
                SELECT mongo_id
                FROM user
                where user.id = {0}
            """
            kwargs['id'] = x1cursor.mysql(user_query, [kwargs['id']]).fetchone()['mongo_id']
        return super(_MongoEngineUserDatastore, self).find_user(**kwargs)


USER_DATASTORE = _MongoEngineUserDatastore(x1cursor.mongo(), User, Role)


class ExtendedRegisterForm(RegisterForm):
    name = StringField(label='Your name', validators=[Required()])
    terms = BooleanField(label='I have read and understood the privacy policy and terms of service', validators=[Required()])


class ExtendedLoginForm(LoginForm):

    def validate(self):

        db_session = x1cursor.mysql_session()
        user = _get(tables.User, session=db_session, email=self.email.data, cacheable=False)
        update_md5_password(self.password.data, user, db_session)

        response = super(ExtendedLoginForm, self).validate()
        return response


SECURITY = Security(app, USER_DATASTORE, register_form=ExtendedRegisterForm, login_form=ExtendedLoginForm)


@SECURITY.context_processor
def security_context_processor():
    return dict(env=request.environ)


@SECURITY.mail_context_processor
def security_mail_processor():
    return dict(env=request.environ, current_user=current_user, enabled_websites=enabled_websites())


@app.before_first_request
def before_first_request():
    """Set a time that the server restarted in a file"""
    try:
        with open('/dev/shm/x1jobs/.restarted', 'w') as restarted_file:
            restarted_file.write(datetime.datetime.now().isoformat())
    except StandardError:
        raise RuntimeError(
            "Cannot write to /dev/shm/x1jobs {e} please ensure that directory exists, is writable, and that the directories igz nto nfj exist within it."
            .format(e=sys.exc_info()))


@app.before_request
def before_request():
    """Update the sending email address for the current site"""
    try:
        regional_branded_email_address = 'servicedesk@{name}.com'.format(name=request.environ['x1sitename'])
        app.config.update(SECURITY_EMAIL_SENDER=regional_branded_email_address)
    except StandardError:
        pass


@app.before_request
def log_whole_request():
    if x1utils.dev_server():
        print request.headers
        print request.get_data()


@app.after_request
def close_session(response):
    """Close and flush any open sessions"""
    session = x1cursor.mysql_session()
    session.flush()
    session.close()
    return response


@password_reset.connect_via(app)
def reset_password(*args, **kwargs):
    users_collection = DBM.get_collection('user')
    user = users_collection.find_one({"email": re.compile('^{email}$'.format(email=kwargs['user']['email']), re.IGNORECASE)})
    if user:
        db_session = x1cursor.mysql_session()
        query = db_session.query(tables.User).filter_by(email=kwargs['user']['email']).first()
        if not query:
            abort(400, 'No user found')
        query.password = user['password']
        db_session.add(query)
        db_session.flush()


@password_changed.connect_via(app)
def change_password(*args, **kwargs):
    if current_user.is_anonymous:
        abort(400, "Need to be logged in to access this endpoint")
    users_collection = DBM.get_collection('user')
    user = users_collection.find_one({"email": re.compile('^{email}$'.format(email=current_user.email), re.IGNORECASE)})
    if not user:
        abort(400, 'No user found')
    db_session = x1cursor.mysql_session()
    query = db_session.query(tables.User).filter_by(email=current_user.email).first()
    if not query:
        abort(400, 'No user found')
    query.password = user['password']
    db_session.add(query)
    db_session.flush()


@user_logged_in.connect_via(app)
def user_has_logged_in(*args, **kwargs):
    """
    Check for any simplified alerts linked to this email address. If any are there then convert them into full alerts.
    """
    try:
        email_address = kwargs['user']['email']
        user_id = kwargs['user']['id']
    except KeyError:
        return

    db_session = x1cursor.mysql_session()
    user = db_session.query(tables.User).filter_by(email=email_address).first()
    if user:
        alerts = db_session.query(tables.JobAlert).filter_by(email=email_address).all()
        for alert in alerts:
            alert.email = None
            alert.user_id = user.id
            db_session.add(alert)
            db_session.flush()

    if 'user_last_core_skill_specified' in session:
        session.pop('user_last_core_skill_specified')


@user_logged_out.connect_via(app)
def on_user_logged_out(*args, **kwargs):
    if 'current_search' in session:
        session.pop('current_search')
    if 'user_last_core_skill_specified' in session:
        session.pop('user_last_core_skill_specified')


@user_registered.connect_via(app)
def sync_new_user(sender, user, **extra):
    try:
        mongo_user = load_user_from_mongo(email_address=user.email)
        synchronise_user(mongo_user)
    except StandardError:
        abort(422, 'Cannot sync new user')


@app.route('/sitemap.xml')
def return_sitemap():
    """returns the correct sitemap for the regional site"""
    site_name = request.environ['x1sitename']
    directory = '{0}{1}/'.format(app.config['SITEMAPS_DIRECTORY'], site_name)
    return send_from_directory(directory, 'sitemap_index.xml')


@app.route('/setDefaultCV')
@login_required
def set_default_cv():
    """Set a users default CV"""
    cv_file_id = request.args.get('q')
    session = x1cursor.mysql_session()
    sql_user = load_user(email_address=current_user.email, session=session)
    for sql_file in sql_user.files:
        sql_file.default_cv = 0
        if sql_file.id == int(cv_file_id):
            sql_file.default_cv = 1
        session.add(sql_file)
    session.flush()
    process_cv(sql_user.id, "add")
    return jsonify({"status": "OK", "updated": cv_file_id})


@app.route('/recommended_jobs')
def recommended_jobs():
    """Return recommended jobs"""
    fields_to_send = [
        'CompanyName', 'SalaryText', 'JobTitle', 'CompanyName', 'url', 'JobLocation', 'CompanyImageURL', '_id', 'CompanySeoURL'
    ]
    total_length = 0
    searches = list()
    result_list = list()

    try:
        limit = int(request.args['limit'])
    except StandardError:
        limit = None

    if 'queries' in request.args:
        try:
            queries = json.loads(unescapeurl(request.args['queries']))
        except ValueError:
            abort(code=400)

        for query in queries:
            params_for_search = {}
            query_string = query['query'].lstrip('/jobs/?')
            for mapping in re.split(r'(?<=[\w=])&(?=\w)', query_string):
                try:
                    key, value = mapping.split('=')
                except StandardError:
                    continue
                if key and value:
                    params_for_search[key] = value

            if limit:
                params_for_search['per_page'] = limit
                params_for_search['page'] = 1

            searches.append(params_for_search)
        for search in searches:
            result = x1searchresults.get_search_results(search, returntype='object', recommended_jobs=True)['results']
            total_length += len(result)

            result_list.append(result)

            if limit and total_length >= limit:
                break
        for results in result_list:
            for result in results:
                if result:
                    for key in result.keys():
                        if key not in fields_to_send and key != "Salary":
                            del result[key]
                        elif key == 'JobLocation':
                            result['City'] = result[key]['City']
                            del result[key]
                        elif key == 'Salary':
                            try:
                                result['SalaryText'] = result[key]['SalaryText']
                            except KeyError:
                                pass
                            del result[key]
                        elif key == '_id':
                            result['_id'] = str(result['_id'])
                        if 'national_location_id' in key:
                            result['national_location_id'] = True
                for required_key in ['CompanyImageURL', 'SalaryText', 'CompanySeoURL']:
                    if required_key not in result:
                        result[required_key] = None

        results = list(chain.from_iterable(result_list))  # Flatten the list of results
        results = list(x1utils.unique_everseen(results, itemgetter('_id')))

        if len(results) > limit:
            results = results[:limit]
        return json.dumps(results)
    else:
        abort(400)


@app.route('/popular_searches')
def popular_searches():
    """Return popular searches for the current site"""
    site_name = request.environ['x1sitename']
    cache_key = 'x1_popular_search_{region}'.format(region=site_name)
    cached_content = x1cache.get(cache_key)
    if cached_content:
        return pickle.loads(cached_content)
    popular_searches_collection = DBM.get_collection('PopularSearches')
    popular_searches_return = json.dumps(list(popular_searches_collection.find({'website': site_name}, {'_id': False})))
    x1cache.set(cache_key, pickle.dumps(popular_searches_return), 86400)
    return popular_searches_return


JOB_MAPPING = {
    "AgencyOrEmployer": {
        "rename_key": "employer_type",
        "values": {
            "U": "Unknown",
            "A": "Agency",
            "E": "Employer"
        }
    },
    "Apprenticeship": {
        "rename_key": "apprenticeship",
        "values": {
            "yes": 1,
            "no": 0
        }
    },
    "ApplyURL": "apply_url",
    "CompanyName": "company_name",
    "ContactEmail": "apply_email",
    "ContactPhone": "apply_phone_number",
    "ContractOrPermanent": {
        "rename_key": "contract_type",
        "values": {
            "U": "Unknown",
            "Contract": "Contract",
            "Permanent": "Permanent",
            "Temporary": "Temporary"
        }
    },
    "ClosingDate": "closing_date",
    "CoreSkillList": "core_skill_list",
    "FullOrPartTime": {
        "rename_key": "hours",
        "values": {
            "U": "Unknown",
            "Full": "Full",
            "Part": "Part"
        }
    },
    "GraduateSuitable": {
        "rename_key": "graduate_suitable",
        "type": "boolean",
        "values": {
            "U": "Unknown",
            True: 1,
            False: 0
        }
    },
    "ImmediateStart": {
        "rename_key": "immediate_start",
        "type": "boolean",
        "values": {
            "U": "Unknown",
            True: 1,
            False: 0
        }
    },
    "JobTitle": "job_title",
    "JobDescription": "job_description",
    "JobLocation__City": None,
    "JobLocation__Country": None,
    "JobLocation__DisplayCity": None,
    "JobLocation__PostalCode": "postcode",
    "JobLocation__StateProvince": None,
    "JobTypeCodeList": None,
    "PublicationDate": None,
    "Salary__CurrencyCode": None,
    "Salary__SalaryText": "salary_text",
    "Salary__BasePayL": "salary_low",
    "Salary__BasePayH": "salary_high",
    "Salary__BasePayPer": "salary_rate",
    "SpecialismList": "specialism_list",
    "VacancyID": "vacancy_id",
    "external_reference": "external_reference",
    "this_job_from": "this_job_from",
    "username": "username",
    "password": "password",
    "skip_location_check": None,
    "skip_company_check": None,
    "PaperTopOpp": "",
    "PaperFeatured": "",
    "job_is_expired": None,
    "CompanyImageURL": "CompanyImageURL",
    "credit_type": "credit_type",
    "RegionalSite": "regional_site",
    "WebAdID": None,
    "Suppress_Customer": "company_confidential",
    "_etag": None,
    "_id": None,
    "_search_location": None,
    "company_urn": "company_urn",
    "CompanyURN": "company_urn"
}


@app.route('/api/v1/Job', methods=['POST'])
@app.route('/api/v1/Job/<job_id>', methods=['PATCH', 'GET'])
def old_job_route(job_id=None):
    """Reroute any job requests through to the new job API"""
    job_json = request.get_json(silent=True)
    if not job_json:
        original_json = None
    else:
        original_json = copy.deepcopy(job_json)
    if request.method == 'GET':
        resp = requests.get(x1utils._get_recruiter_url(job_id))
    else:
        location_data = None
        if job_json.get('JobLocation__City') and job_json.get('JobLocation__PostalCode'):
            location_data = x1utils.check_location(job_json.get('JobLocation__City'), job_json.get('JobLocation__PostalCode'))
        job_type_code_list = job_json.get("JobTypeCodeList")
        job_json = map_job(request.get_json())
        if location_data:
            job_json['location_label'] = location_data.lower()
        job_json['company_confidential'] = False
        if not job_json.get("core_skill_list"):
            if job_type_code_list:
                job_json['core_skill_list'] = job_type_code_list.split("&&")
            else:
                job_json['core_skill_list'] = []
        if request.method == 'POST':
            resp = requests.post(x1utils._get_recruiter_url(), json=job_json)
        else:
            resp = requests.patch(x1utils._get_recruiter_url(job_id), json=job_json, headers={'If-Match': request.headers['If-Match']})
    try:
        resp.raise_for_status()
        JOB_POST_LOGGER.info('Method: %s, IP Address: %s, Status %s, job json %s', request.method, request.remote_addr, resp.status_code,
                             original_json)
        JOB_POST_LOGGER.info('Status of job post parts: %s', resp.json())
        JOB_POST_LOGGER.info('-------------------------------------------------------------------------------------')
    except StandardError:
        try:
            JOB_POST_LOGGER.warning('Method: %s, IP Address: %s, Status %s, error %s, job json %s', request.method, request.remote_addr,
                                    resp.status_code, resp.json(), original_json)
        except:
            JOB_POST_LOGGER.warning('Method: %s, IP Address: %s, Status %s, error Unknown, job json %s', request.method,
                                    request.remote_addr, resp.status_code, original_json)
        JOB_POST_LOGGER.warning('-------------------------------------------------------------------------------------')
        abort(resp.status_code, resp.content)
    data = resp.json()
    if "id" in data.keys():
        data['_id'] = data.pop("id")
    if data.get("status"):
        data.pop("status")

    return make_response(jsonify(data), resp.status_code)


@app.route('/get_talent_pool_wrapped', methods=['GET'])
def get_talent_pool_wrapped():
    session = x1cursor.mysql_session()
    if current_user.is_anonymous:
        abort(409, "Need to be logged in to access this endpoint")

    activity_log_type = _get(tables.ActivityLogType, session, type='talent pool message')
    user_record = _get(tables.User, session=session, email=current_user.email, cacheable=False)
    #Query the ActivityLog table and filter by the newest messages and then group by to only return the newest one
    query = session.query(tables.ActivityLog.talent_pool_member_id,
                          func.max(tables.ActivityLog._created).label("_created")).filter_by(to_user_id=user_record.id,
                                                                                             activity_log_type_id=activity_log_type.id)
    query = query.group_by(tables.ActivityLog.talent_pool_member_id)
    total_results = 0

    try:
        if query.first():
            total_results = query.count()
    except StandardError as e:
        print e
    sort = request.args.get("sort")
    q_options = parse_paging_and_sorting_options()
    query = query.order_by(*q_options['sort'])
    query = query.limit(q_options['limit'])
    query = query.offset(q_options['offset'])
    results = []
    try:
        for row in query.all():

            #The following 3 queries determines what company the talent pool recruiter comes from
            talent_pool_member_object = _get(tables.TalentPoolMember, session=session, id=row.talent_pool_member_id, cacheable=False)
            talent_pool_object = _get(tables.TalentPool, session=session, id=talent_pool_member_object.talent_pool_id, cacheable=False)
            company = _get(tables.Company, session=session, company_id=talent_pool_object.company_id, cacheable=False)

            #Query the activity log table again to get the subject. We couldnt do this before because the group by would be affected
            activity_log = session.query(tables.ActivityLog).filter_by(talent_pool_member_id=row.talent_pool_member_id,
                                                                       _created=row._created).first()

            record = {}
            record['title'] = activity_log.subject
            record['from_user_name'] = activity_log.from_user.name
            record['company_name'] = company.company_name
            record['talent_pool_member_id'] = row.talent_pool_member_id
            record['unseen_messages'] = has_new_messages(row, session)
            results.append(record)
    except StandardError as e:
        print e

    items = format_endpoint_output(q_options, total_results, results, sort)

    if sort:  #sort in q_options is a sqlalchemy sort object but want the text names instead so get them from the request and return them to the surrounding pages method
        q_options['sort'] = sort.split(",")

    links = get_surrounding_pages("/get_talent_pool_wrapped", q_options, request.args, total_results)
    items["links"] = links

    return Response(json.dumps(items, default=str), mimetype='application/json')


def has_new_messages(row, session):
    activity_log_type = _get(tables.ActivityLogType, session=session, type='talent pool message', cacheable=False)
    query = session.query(tables.ActivityLog)
    query = query.filter_by(talent_pool_member_id=row.talent_pool_member_id, jobseeker_seen=0, activity_log_type_id=activity_log_type.id)
    try:
        if query.all():
            return True
    except StandardError as e:
        print e


@app.route('/get_talent_pool_unwrapped/<talent_pool_member_id>', methods=['GET'])
def get_talent_pool_unwrapped(talent_pool_member_id):
    session = x1cursor.mysql_session()
    if current_user.is_anonymous:
        abort(409, "Need to be logged in to access this endpoint")

    activity_log_type = _get(tables.ActivityLogType, session, type='talent pool message')
    user_record = _get(tables.User, session=session, email=current_user.email, cacheable=False)
    live_status = _get(tables.ProductStatus, session, status='live')
    try:
        talent_pool_member_object = _get(tables.TalentPoolMember,
                                         session=session,
                                         id=talent_pool_member_id,
                                         status_id=live_status.id,
                                         cacheable=False)
        if not user_record.id == talent_pool_member_object.user_id:
            abort(400, "You don't have permission to view this")
    except Exception:
        abort(400, 'Member id doesnt exist')

    query = session.query(tables.ActivityLog).filter_by(talent_pool_member_id=talent_pool_member_id,
                                                        activity_log_type_id=activity_log_type.id)
    query = query.order_by(tables.ActivityLog._created.desc())

    update_jobseeker_messages_to_read(session=session, talent_pool_member_id=talent_pool_member_id)

    results = []
    for row in query.all():
        record = {}
        record['title'] = row.subject
        record['body'] = row.body
        record['from_user_name'] = row.from_user.name
        record['to_user_name'] = row.to_user.name
        record['from_user_email'] = row.from_user.email
        record['to_user_email'] = row.to_user.email
        record['from_user_id'] = row.from_user.id
        record['to_user_id'] = row.to_user.id
        record['_created'] = row._created,
        if row.job_id:
            record['job_url'] = row.job.canonical_url
            record['company_name'] = row.job.company.company_name
        record['talent_pool_member_id'] = row.talent_pool_member_id
        record['talent_pool_user_id'] = talent_pool_member_object.user_id
        results.append(record)

    return Response(json.dumps(results, default=str), mimetype='application/json')


@app.route('/application_history/<job_id>', methods=['GET'])
def get_application_history(job_id):
    """This endpoint is called on the application history page once a jobseeker clicks on a specific application"""
    session = x1cursor.mysql_session()
    try:
        int(job_id)
    except ValueError:
        job_record = _get(tables.Job, session=session, mongo_id=job_id, cacheable=False)
    else:
        job_record = _get(tables.Job, session=session, id=job_id, cacheable=False)
    if not job_record:
        abort(400, "Job does not exist")
    if current_user.is_anonymous:
        abort(400, "User is not logged in")
    user_record = _get(tables.User, session=session, email=current_user.email, cacheable=False)
    if not user_record:
        abort(400, "No user found")

    query = session.query(tables.JobApplication)
    query = query.filter_by(user_id=user_record.id, job_id=job_id)
    query = query.outerjoin(tables.JobApplication.activity_log)
    query = query.outerjoin(tables.ActivityLog.activity_log_type)
    job_application_record = query.first()

    if not job_application_record:
        abort(400, "No application for this job from the current user")

    update_jobseeker_messages_to_read(session=session, application_id=job_application_record.id)

    job_dict = render_job_dict(job_record)
    job_dict['job_application_id'] = job_application_record.id
    job_dict['current_user'] = user_record.id
    job_dict["activity_log"] = []
    for activity in job_application_record.activity_log:
        if activity.activity_log_type.type in ('schedule interview', 'review', 'reject', 'job offer', 'custom'):
            from_user_object = _get(tables.User, session=session, id=activity.from_user_id, cacheable=False)
            to_user_object = _get(tables.User, session=session, id=activity.to_user_id, cacheable=False)
            job_dict["activity_log"].append({
                "from_user": from_user_object.name,
                "from_user_id": from_user_object.id,
                "to_user": to_user_object.name,
                "to_user_id": to_user_object.id,
                "subject": activity.subject,
                "body": activity.body
            })
    job_dict["activity_log"].reverse()

    return jsonify(job_dict)


def update_jobseeker_messages_to_read(session, application_id=None, talent_pool_member_id=None):
    activity_log_query = session.query(tables.ActivityLog)
    if application_id:
        activity_log_query = activity_log_query.filter_by(application_id=application_id)
    if talent_pool_member_id:
        activity_log_query = activity_log_query.filter_by(talent_pool_member_id=talent_pool_member_id)
    for row in activity_log_query.all():
        row.jobseeker_seen = 1
        row._etag = generate_etag()
        session.add(row)
    try:
        session.flush()
    except StandardError as e:
        print e


@app.route('/get_current_cvdb_id', methods=['GET'])
def get_current_cvdb_id():
    if current_user.is_anonymous:
        cvdb_list = []
        return make_response(json.dumps({"cvdb_list": cvdb_list}, default=str), 200, {"content-type": 'application/json'})
    db_session = x1cursor.mysql_session()
    user_id = _get(tables.User, db_session, email=current_user.email).id
    cvdb_list = x1utils.get_current_cvdb_id(user_id)
    return make_response(json.dumps({"cvdb_list": cvdb_list}, default=str), 200, {"content-type": 'application/json'})


def user_owns_file(db_session, file_record):
    try:
        user_id = _get(tables.User, db_session, email=current_user.email).id
        if not file_record.user_id == user_id:
            abort(400, "User doesnt own file")
    except StandardError as e:
        print e


def get_default_file_record(db_session, user_id):
    file_record = None
    live_status = db_session.query(tables.ProductStatus).filter_by(status="live").first()
    file_record = _get(tables.Files, db_session, user_id=user_id, default_cv=1, status_id=live_status.id)
    return file_record


def cvdb_authentication(db_session):
    if current_user.is_anonymous:
        abort(403, 'User is not logged in')
    json_data = request.get_json()
    if not json_data:
        abort(400, "Does not appear to be valid json")
    old_file_record = None
    if json_data['cvdb_file_id'] is not None:
        old_file_record = _get(tables.Files, db_session, id=json_data['cvdb_file_id'])
        if not old_file_record:
            abort(400, "CVDB id doesnt relate to a id in the db")
        user_owns_file(db_session, old_file_record)
    file_record = None
    if 'file_id' in json_data:
        file_record = _get(tables.Files, db_session, id=json_data['file_id'])
        if not file_record:
            abort(400, 'File id doesnt exist')
        user_owns_file(db_session, file_record)
    if 'action' in json_data:
        action_list = ['add', 'remove']
        if not json_data['action'] in action_list:
            abort(400, 'Unknown action')
    return old_file_record, file_record, json_data


@app.route('/cvdb_logging', methods=['POST'])
def cvdb_logging():
    db_session = x1cursor.mysql_session()
    old_file_record, file_record, json_data = cvdb_authentication(db_session)
    try:
        cvdb_reporting_record = None
        cvdb_reporting_record_add = None
        cvdb_reporting_record_update = None
        user_id = _get(tables.User, db_session, email=current_user.email).id
        #Determine where the flow is coming from
        if request.headers.get('Referer'):
            if 'account-setup' in request.headers.get("Referer") or 'settings' in request.headers.get('Referer'):
                json_data['page'] = 'settings'
            elif 'my-cvs' in request.headers.get("Referer"):
                json_data['page'] = 'my-cvs'
            elif '/job/' in request.headers.get("Referer"):
                json_data['page'] = 'job-apply'

        if json_data['page'] == 'settings':
            #This is for the register page and the account settings
            if check_user_is_opted_in(user_id, db_session):
                #We check if the user has opt in, we add their default CV to CVDB.
                file_record = get_default_file_record(db_session, user_id)
                if not file_record:
                    abort(200, 'No default to add')
                #We now check if the user has previously had this CV in CVDB, and if so, we add the core skill.
                site_record = _get(tables.Sites, db_session, site_id=file_record.site_id)
                query = db_session.query(tables.CVDBReportingUser).filter_by(file_id=file_record.id)
                query = query.order_by(desc(tables.CVDBReportingUser._created))
                query = query.first()
                if query:
                    cvdb_reporting_record_add = build_CVDB_report(site_record=site_record,
                                                                  action='Add',
                                                                  file_record=file_record,
                                                                  query=query)
                else:
                    cvdb_reporting_record_add = build_CVDB_report(site_record=site_record, action='Add', file_record=file_record)
            elif not check_user_is_opted_in(user_id, db_session) and json_data['cvdb_file_id'] is not None:
                #If the user has opted out, and we had a CV in CVDB, we need to record it being removed.
                site_record = _get(tables.Sites, db_session, site_id=old_file_record.site_id)
                query = db_session.query(tables.CVDBReportingUser).filter_by(file_id=old_file_record.id)
                query = query.order_by(desc(tables.CVDBReportingUser._created))
                query = query.first()
                if query:
                    cvdb_reporting_record = build_CVDB_report(site_record=site_record,
                                                              action='Remove',
                                                              file_record=old_file_record,
                                                              query=query)
                else:
                    cvdb_reporting_record = build_CVDB_report(site_record=site_record, action='Remove', file_record=old_file_record)
            else:
                #Else, we know that the user has opt out, but has no CV in CVDB to remove.
                abort(200, 'User has no CV to remove')
        elif json_data['page'] == 'my-cvs':
            #If the flow comes from my-cvs, we either ADD a new CV, UPDATE the current one, or REMOVE one.
            if not check_user_is_opted_in(user_id, db_session):
                abort(200, 'User not opt in. Nothing to be logged')
            if json_data['action'] == 'add':
                #If you add a CV or update, there should be a live default CV. If not, we dont log anything.
                file_record = get_default_file_record(db_session, user_id)
                if not file_record:
                    abort(200, 'No default CV')
                if not 'file_id' in json_data:
                    abort(400, 'No file id sent')
                if not file_record.id == json_data['file_id']:
                    abort(200, 'CV being added is not the default')
                if json_data['cvdb_file_id'] is None:
                    #If we don't have a CV currently in CVDB. We add a new one.
                    core_skill = get_core_skill(user_id, db_session)
                    site_record = _get(tables.Sites, db_session, site_id=file_record.site_id)
                    cvdb_reporting_record_add = build_CVDB_report(site_record=site_record,
                                                                  action='Add',
                                                                  file_record=file_record,
                                                                  core_skill=core_skill)

                elif json_data['cvdb_file_id'] == json_data['file_id']:
                    #If we update the CV in my-cvs to my current default CV, we update it.
                    core_skill = get_core_skill(user_id, db_session)
                    site_record = _get(tables.Sites, db_session, site_id=old_file_record.site_id)
                    cvdb_reporting_record_update = build_CVDB_report(site_record=site_record,
                                                                     action='Update',
                                                                     file_record=old_file_record,
                                                                     core_skill=core_skill)
                else:
                    #If we upload a new file or change the default CV, we remove the old and add the new one. We need to check that the new one is classed as the default.
                    query = db_session.query(tables.CVDBReportingUser).filter_by(file_id=old_file_record.id)
                    query = query.order_by(desc(tables.CVDBReportingUser._created))
                    query = query.first()
                    site_record = _get(tables.Sites, db_session, site_id=old_file_record.site_id)
                    if query:
                        cvdb_reporting_record = build_CVDB_report(site_record=site_record,
                                                                  action='Remove',
                                                                  file_record=old_file_record,
                                                                  query=query)
                    else:
                        cvdb_reporting_record = build_CVDB_report(site_record=site_record, action='Remove', file_record=old_file_record)
                    core_skill = get_core_skill(user_id, db_session)
                    site_record = _get(tables.Sites, db_session, site_id=file_record.site_id)
                    cvdb_reporting_record_add = build_CVDB_report(site_record=site_record,
                                                                  action='Add',
                                                                  file_record=file_record,
                                                                  core_skill=core_skill)

            elif json_data['action'] == 'remove':
                #If we have a file in CVDB, and this file is the same id as the one being removed, we know to log the removal from CVDB.
                if json_data['cvdb_file_id'] is None:
                    abort(200, 'No CV in CVDB')
                if 'file_id' not in json_data:
                    abort(400, 'No file id sent')
                if json_data['cvdb_file_id'] == json_data['file_id']:
                    site_record = _get(tables.Sites, db_session, site_id=old_file_record.site_id)
                    query = db_session.query(tables.CVDBReportingUser).filter_by(file_id=old_file_record.id)
                    query = query.order_by(desc(tables.CVDBReportingUser._created))
                    query = query.first()
                    if query:
                        cvdb_reporting_record = build_CVDB_report(site_record=site_record,
                                                                  action='Remove',
                                                                  file_record=old_file_record,
                                                                  query=query)
                    else:
                        cvdb_reporting_record = build_CVDB_report(site_record=site_record, action='Remove', file_record=old_file_record)
                else:
                    abort(200, 'File being deleted is not the one in CVDB. No log needed')
        elif json_data['page'] == 'job-apply':
            if check_user_is_opted_in(user_id, db_session):
                #If the opt in, we need to check to see whether to update their CV, or remove and add a new one.
                if not check_last_application_used_cv(db_session, user_id):
                    abort(200, 'User applied for job without CV')
                if not 'file_id' in json_data:
                    file_record = get_last_applied_for_file_record(db_session, user_id)
                    if not file_record:
                        abort(200, 'User applied for job with non default upload CV')
                    if file_record.id:
                        json_data['file_id'] = file_record.id
                    else:
                        abort(200, 'User applied for a job with non default upload CV')
                live_status = db_session.query(tables.ProductStatus).filter_by(status="live").first()
                default_file = _get(tables.Files, db_session, id=json_data['file_id'], default_cv=1, status_id=live_status.id)
                if not default_file:
                    abort(200, 'User applied for job with non default CV')
                if json_data['cvdb_file_id'] is None:
                    #If there is no CVDB file id, we know there is currently no file in CVDB and so we ADD.
                    core_skill = get_core_skill(user_id, db_session)
                    site_record = _get(tables.Sites, db_session, site_id=file_record.site_id)
                    cvdb_reporting_record_add = build_CVDB_report(site_record=site_record,
                                                                  action='Add',
                                                                  file_record=file_record,
                                                                  core_skill=core_skill)
                elif json_data['cvdb_file_id'] == json_data['file_id']:
                    #If we update the CV in my-cvs to my current default CV, we update it.
                    core_skill = get_core_skill(user_id, db_session)
                    site_record = _get(tables.Sites, db_session, site_id=old_file_record.site_id)
                    cvdb_reporting_record_update = build_CVDB_report(site_record=site_record,
                                                                     action='Update',
                                                                     file_record=old_file_record,
                                                                     core_skill=core_skill)
                else:
                    #We know that there is a CV in CVDB and our CV is different to this CV. We need to remove the old one and add the new one.
                    query = db_session.query(tables.CVDBReportingUser).filter_by(file_id=old_file_record.id)
                    query = query.order_by(desc(tables.CVDBReportingUser._created))
                    query = query.first()
                    site_record = _get(tables.Sites, db_session, site_id=old_file_record.site_id)
                    if query:
                        cvdb_reporting_record = build_CVDB_report(site_record=site_record,
                                                                  action='Remove',
                                                                  file_record=old_file_record,
                                                                  query=query)
                    else:
                        cvdb_reporting_record = build_CVDB_report(site_record=site_record, action='Remove', file_record=old_file_record)
                    core_skill = get_core_skill(user_id, db_session)
                    site_record = _get(tables.Sites, db_session, site_id=file_record.site_id)
                    cvdb_reporting_record_add = build_CVDB_report(site_record=site_record,
                                                                  action='Add',
                                                                  file_record=file_record,
                                                                  core_skill=core_skill)

            elif not check_user_is_opted_in(user_id, db_session) and json_data['cvdb_file_id'] is not None:
                #If the user has opted out, and we had a CV in CVDB, we need to record it being removed.
                site_record = _get(tables.Sites, db_session, site_id=old_file_record.site_id)
                query = db_session.query(tables.CVDBReportingUser).filter_by(file_id=old_file_record.id)
                query = query.order_by(desc(tables.CVDBReportingUser._created))
                query = query.first()
                if query:
                    cvdb_reporting_record = build_CVDB_report(site_record=site_record,
                                                              action='Remove',
                                                              file_record=old_file_record,
                                                              query=query)
                else:
                    cvdb_reporting_record = build_CVDB_report(site_record=site_record, action='Remove', file_record=old_file_record)

        try:
            if cvdb_reporting_record:
                db_session.add(cvdb_reporting_record)
            if cvdb_reporting_record_update:
                db_session.add(cvdb_reporting_record_update)
            if cvdb_reporting_record_add:
                db_session.add(cvdb_reporting_record_add)
            db_session.flush()
        except StandardError as e:
            print e

        return make_response(json.dumps({'status': {"code": 200, "message": "CVDB updated logged"}}), 200)
    except StandardError as e:
        print e
        return make_response(json.dumps({'status': {"code": 200, "message": "CVDB not logged. Mongo SQL user issue."}}), 200)


def get_last_applied_for_file_record(db_session, user_id):
    query = db_session.query(tables.JobApplication).filter_by(user_id=user_id)
    query = query.order_by(desc(tables.JobApplication._created))
    query = query.first()
    if query:
        application_file = _get(tables.relationships.application_files, application_id=query.id, session=db_session)
        if application_file:
            file_record = _get(tables.Files, id=application_file.file_id, session=db_session)
            if file_record.default_cv == 1:
                return file_record
    return False


def check_last_application_used_cv(db_session, user_id):
    query = db_session.query(tables.JobApplication).filter_by(user_id=user_id)
    query = query.order_by(desc(tables.JobApplication._created))
    query = query.first()
    if query:
        application_file = _get(tables.relationships.application_files, application_id=query.id, session=db_session)
        if application_file:
            return True
    return False


def build_CVDB_report(site_record, action, file_record, query=None, core_skill=None):
    if query:
        cvdb_reporting_record = tables.CVDBReportingUser(site_name=site_record.site_name,
                                                         core_skill=query.core_skill if query.core_skill else None,
                                                         cv_created_date=file_record._created,
                                                         user_action=action,
                                                         file_id=file_record.id)
    elif core_skill:
        cvdb_reporting_record = tables.CVDBReportingUser(site_name=site_record.site_name,
                                                         core_skill=core_skill.core_skill if core_skill else None,
                                                         cv_created_date=file_record._created,
                                                         user_action=action,
                                                         file_id=file_record.id)

    else:
        cvdb_reporting_record = tables.CVDBReportingUser(site_name=site_record.site_name,
                                                         core_skill=None,
                                                         cv_created_date=file_record._created,
                                                         user_action=action,
                                                         file_id=file_record.id)
    return cvdb_reporting_record


def get_core_skill(user_id, session):
    core_skill = None
    query = session.query(tables.JobApplication).filter_by(user_id=user_id)
    query = query.order_by(desc(tables.JobApplication._created))
    query = query.first()
    if query:
        application_file = _get(tables.relationships.application_files, application_id=query.id, session=session)
        if application_file:
            file_record = _get(tables.Files, id=application_file.file_id, session=session)
            if file_record.default_cv == 1:
                job_core_skill = _get(tables.relationships.job_core_skills, job_id=query.job_id, session=session)
                core_skill = _get(tables.CoreSkill, id=job_core_skill.core_skill_id, session=session)
    return core_skill


@app.route('/api/v1/File/<file_id>', methods=['PATCH'])
def old_file_route_patch(file_id):
    """Reroute any file requests through to the new API"""
    file_json = request.get_json(silent=True)
    file_json = map_file_patch(file_json)
    response = file_patch(file_id, etag=request.headers.get('If-Match'), update_json_data=file_json)
    return response


def map_file_patch(file_json):
    if 'deleted' in file_json:
        file_json['status'] = 'deleted'
        del file_json['deleted']
    return file_json


@app.route('/api/v1/File/', methods=['POST'])
def old_file_route_post():
    """Reroute any file requests through to the new API"""
    file_json = request.get_json(silent=True)
    file_json = map_file_post(file_json)
    response = file_post(file_json)
    return response


FILE_MAP_DELETE = ['content_type']


def map_file_post(file_json):
    for key, value in file_json.items():
        if key in FILE_MAP_DELETE:
            del file_json[key]
        if value == '':
            del file_json[key]
    return file_json


@app.route('/api/v1/File', methods=['GET'])
@app.route('/api/v1/File/<file_id>', methods=['GET'])
def old_file_route_get(file_id=None):
    """Reroute any file requests through to the new API"""
    if file_id:
        resp = file_get()
    else:
        resp = file_search()
    if resp.status_code != 200:
        abort(resp.status_code, resp.data)
    data = json.loads(resp.data)
    for cv in data:
        cv = map_file_get(cv)

    response = make_response(json.dumps({'_items': data}, default=str), resp.status_code)
    response.headers['Content-Type'] = 'application/json'
    return response


def convert_date_to_mongo(date):
    if not isinstance(date, datetime.datetime):
        date_obj = datetime.datetime.strptime(date, '%Y-%m-%d %H:%M:%S')
    else:
        date_obj = date
    return date_obj.strftime('%a, %d %b %Y %H:%M:%S')


FILE_MAP = {
    'id': '_id',
    'default_cv': {
        'func': x1utils.coerce_to_bool
    },
    'cv_review': {
        'func': x1utils.coerce_to_bool
    },
    'career_profile_cv': {
        'func': x1utils.coerce_to_bool
    },
    'site_id': 'saved_on',
    '_created': {
        'func': convert_date_to_mongo
    },
    '_updated': {
        'func': convert_date_to_mongo
    }
}


def map_file_get(cv):
    for key, value in FILE_MAP.iteritems():
        if key in cv:
            if isinstance(value, dict):
                if 'func' in value:
                    cv[key] = value['func'](cv[key])
            else:
                cv[value] = cv[key]
                del cv[key]
    return cv


@app.route("/saved_job/<job_id>", methods=["GET"])
def get_saved_job(job_id):
    session = x1cursor.mysql_session()
    job, user = saved_job_auth(job_id)
    job_application = _get(tables.JobApplication, session=session, cacheable=False, job_id=int(job_id), user_id=user.id)
    job = job.to_mongo()
    if job_application:
        job['application_date'] = job_application._created
    return make_response(jsonify(job), 200)


@app.route("/api/v1/SavedJob", methods=["POST"])
def post_saved_job():
    session = x1cursor.mysql_session()
    job_id = request.form['job_id']
    job, user = saved_job_auth(job_id)
    saved_job = session.query(tables.UserStoredJob).filter_by(user_id=user.id, job_id=job.id, status="live").first()
    if saved_job:
        abort(400, "Already have saved this job")
    new_saved_job = tables.UserStoredJob(user_id=user.id, job_id=job.id, status="live", saved_on=request.environ['x1sitename'])
    try:
        session.add(new_saved_job)
        session.flush()
    except:
        abort(400, "Failed to add new saved job")
    return jsonify({'Message': "Posted new saved job"}), 200


@app.route("/saved_job", methods=["GET"])
def get_all_saved_job():
    session = x1cursor.mysql_session()
    if current_user.is_anonymous:
        abort(403, 'User must login first')
    user = load_user(email_address=current_user.email, session=session, anonymous_allowed=True)
    sort = request.args.get("sort")
    query = session.query(tables.UserStoredJob)
    query = query.filter_by(user_id=user.id, status='live')
    query = query.join(tables.Job)
    query = query.join(tables.Company)
    total_results = 0
    try:
        if query.first():
            total_results = query.count()
    except StandardError as e:
        print e
    q_options = parse_paging_and_sorting_options()
    query = query.order_by(*q_options['sort'])
    query = query.limit(999)
    query = query.offset(q_options['offset'])
    jobs = []
    for row in query.all():
        temp = {}
        temp['_updated'] = row._updated
        temp['job_id'] = row.job.id
        temp['title'] = row.job.job_title
        temp['company_name'] = row.job.company.company_name
        temp['_created'] = row._created
        temp['_id'] = row.id
        temp['_etag'] = row._etag
        temp['saved_on'] = row.saved_on
        jobs.append(temp)
    items = format_endpoint_output(q_options, total_results, jobs, sort)
    if sort:  #sort in q_options is a sqlalchemy sort object but want the text names instead so get them from the request and return them to the surrounding pages method
        q_options['sort'] = sort.split(",")
    links = get_surrounding_pages("/saved_job", q_options, request.args, total_results)
    items["links"] = links

    return Response(json.dumps(items, default=str), mimetype='application/json')


@app.route("/saved_job/<job_id>", methods=["PATCH"])
def delete_saved_job(job_id):
    session = x1cursor.mysql_session()
    if current_user.is_anonymous:
        abort(403, 'User must login first')
    try:
        user = load_user(email_address=current_user.email, session=session, anonymous_allowed=True)
    except StandardError:
        abort(400, "SQL Mongo user sync issue")
    try:
        job_id = int(job_id)
    except StandardError:
        abort(422, "non integer job id sent")
    saved_job = _get(tables.UserStoredJob, user_id=user.id, id=job_id, status='live')
    if not saved_job:
        abort(400, "No saved job to delete")
    saved_job.status = 'deleted'
    saved_job._etag = generate_etag()
    session.add(saved_job)
    session.flush()
    session.refresh(saved_job)
    return jsonify({'Message': "Deleted saved job"}), 200


def saved_job_auth(job_id):
    session = x1cursor.mysql_session()
    if current_user.is_anonymous:
        abort(403, 'User must login first')
    try:
        user = load_user(email_address=current_user.email, session=session, anonymous_allowed=True)
    except StandardError:
        abort(400, "SQL Mongo user sync issue")
    try:
        job_id = int(job_id)
    except StandardError:
        abort(422, "non integer job id sent")
    job = _get(tables.Job, session=session, cacheable=True, id=int(job_id))
    if not job:
        abort(400, "No job for this id")
    return job, user


def flatten_salary(job_json):
    """Convert a salary to a dict"""
    if "Salary" in job_json:
        for key in job_json['Salary'].keys():
            job_json["Salary__{0}".format(key)] = job_json['Salary'][key]
        job_json.pop("Salary")
    return job_json


def map_job(job_json):
    """Map a job from the old job API to the new job API"""
    job_json = flatten_salary(job_json)
    for json_key in job_json.keys():
        if json_key in JOB_MAPPING:
            if JOB_MAPPING[json_key]:
                if isinstance(JOB_MAPPING[json_key], dict):  # If the mapping contains a dictionary
                    if JOB_MAPPING[json_key].get(
                            'type') == 'boolean':  # If the dictionary is marked as a boolean, the value needs converted to a bool first
                        job_json[json_key] = x1utils.coerce_to_bool(job_json[json_key])
                    job_json[JOB_MAPPING[json_key]['rename_key']] = JOB_MAPPING[json_key]['values'][
                        job_json[json_key]]  # Set the new keys value
                    if JOB_MAPPING[json_key]['rename_key'] != json_key:  # If it's not the same as the old key, remove the old key
                        del job_json[json_key]
                else:
                    job_json[JOB_MAPPING[json_key]] = job_json.pop(json_key)
            else:
                job_json.pop(json_key)
        else:
            print 'Aborting, unknown json_key found: {0}'.format(json_key)
            abort(500)
    return job_json


def return_featured_companies():
    """Get featured companies for the homepage"""
    featured_companies_cache_key = 'featured-companies-{sitename}'.format(sitename=request.environ['x1sitename'])
    lock_key = 'lock + {cache_key}'.format(cache_key=featured_companies_cache_key)
    cached_featured_companies = x1utils.return_cache_or_set_lock(featured_companies_cache_key, lock_key)
    if cached_featured_companies:
        try:
            return cached_featured_companies
        except StandardError:
            featured_companies = None
    else:
        featured_companies = None

    if not featured_companies:
        try:
            sitename = request.environ['x1sitename']
            if sitename == 'any1jobs':
                sitename = None

            featured_companies = x1jobsearchresultsetSQL.get_featured_companies(sitename=sitename,
                                                                                limit=config.get('homepage',
                                                                                                 'max_homepage_featured_companies'))

        except StandardError:
            pass
        else:
            x1cache.set(featured_companies_cache_key,
                        pickle.dumps(featured_companies),
                        expires=config.getint('cache-times', 'cache_time_homepage_featured_companies'))

    try:
        if config.getboolean('homepage', 'shuffle_homepage_featured_companies'):
            shuffle(featured_companies)
    except StandardError:
        pass

    if not featured_companies:
        featured_companies = list()
    x1cache.cache_delete(lock_key)
    return featured_companies


@app.route('/featured_jobs')
def return_featured_jobs(no_json=False):
    """Get featured jobs for the homepage"""

    if 'limit' in request.args:
        try:
            limit = int(request.args['limit'])
        except StandardError:
            limit = config.getint('homepage', 'max_homepage_featured_jobs')
    else:
        limit = config.getint('homepage', 'max_homepage_featured_jobs')

    featured_jobs_cache_key = 'featured-abcd-jobs-{environment}-{limit}-api'.format(environment=request.environ['x1sitename'], limit=limit)
    cached_featured_jobs = x1cache.get(featured_jobs_cache_key)

    if cached_featured_jobs:  # pickled content
        try:
            cached_featured_jobs = pickle.loads(cached_featured_jobs)
            featured_jobs = cached_featured_jobs
        except StandardError:
            featured_jobs = None
    else:
        sitename = request.environ['x1sitename']
        if sitename == 'any1jobs':
            sitename = None

        try:
            featured_jobs = x1jobsearchresultsetSQL.get_featured_jobs(sitename=sitename, limit=limit)
        except StandardError:
            if x1utils.dev_server():
                raise
            else:
                pass

        if len(featured_jobs) > limit:
            featured_jobs = featured_jobs[:limit]

        fields_to_send = ['JobTitle', 'CompanyName', 'url', 'JobLocation', 'CompanyImageURL', 'Salary', '_id']

        for job in featured_jobs:
            for key in job.keys():
                if key not in fields_to_send:
                    del job[key]
                elif key == 'JobLocation':
                    job['City'] = job[key]['City']
                    del job[key]
                elif key == 'Salary':
                    try:
                        job['SalaryText'] = job[key]['SalaryText']
                    except KeyError:
                        pass
                    del job[key]
                elif key == '_id':
                    job['_id'] = str(job[key])
            for required_key in ['CompanyImageURL', 'SalaryText']:
                if required_key not in job:
                    job[required_key] = None
        x1cache.set(featured_jobs_cache_key,
                    pickle.dumps(featured_jobs),
                    expires=config.getint('cache-times', 'cache_time_homepage_featured_jobs'))

    if not no_json:
        featured_jobs = json.dumps(featured_jobs)

    return featured_jobs


@app.route('/radial_search')
def radial_search_endpoint():
    """Return similar jobs"""
    if '_id' in request.args:
        rows = request.args.get('rows', 5)
        sort = request.args.get('sort', None)
        distance = request.args.get('Distance', 5)

        cache_key = 'x1-radial-search-{id}-{rows}-{distance}-{sort}'.format(id=request.args['_id'], rows=rows, distance=distance, sort=sort)
        cached_content = x1cache.get(cache_key)
        if cached_content:
            results = pickle.loads(cached_content)

        else:
            _db = x1cursor.mongo().get_database(config.get('mongo', 'database'))
            db_session = x1cursor.mysql_session()
            if sort:
                job_stats_collection = _db.get_collection('JobStats')
            query = db_session.query(tables.Job).filter_by(id=request.args['_id'])
            job = query.one_or_none()
            result_list = list()
            for core_skill in job.core_skills:
                result_list.append(
                    x1searchresults.get_search_results(
                        {
                            'JobLocationCity': job.location.name1,
                            'Distance': distance,
                            'JobTypeCodeList': core_skill,
                            'per_page': rows
                        },
                        returntype='object',
                        region=request.environ['x1sitename'])['results'])
            results = list(chain.from_iterable(result_list))  # Flatten the list of lists
            if len(results) > int(rows):
                results = results[:int(rows)]

            results = {v['url']: v for v in results}.values()  # Remove duplicates

            if sort:
                for job in results:
                    try:
                        job[sort] = job_stats_collection.find_one({"VacancyID": job['VacancyID']}, {sort: True})[sort]
                    except (StandardError, InvalidDocument):
                        job[sort] = 0
                results = sorted(results, key=itemgetter(sort), reverse=True)

            fields_to_send = ['JobTitle', 'CompanyName', 'url', 'JobLocation', 'national_location_id']
            for result in results:
                if 'national_location_id' in result:
                    result['national_location_id'] = True
                if result.get('_id') == request.args['_id']:
                    results.remove(result)
                for key in result.keys():
                    if key not in fields_to_send:
                        del result[key]
                    elif key == 'JobLocation':
                        result['City'] = result[key]['City']
                        del result[key]

        #XS-2194 fixing date not compatible with json bug
        for result in results:
            for key, item in result.iteritems():
                if isinstance(item, datetime.datetime):
                    result[key] = item.isoformat()

        x1cache.set(cachekey=cache_key, content=pickle.dumps(results), expires=7200)
        return json.dumps(results)
    else:
        abort(400)


@app.route('/ping')
def ping():
    return 'pong'


@app.route('/api/v1/token')
@login_required
def get_auth_token(expires_seconds=config.getint('misc', 'json_token_expires_default')):
    """Get a users auth token"""
    token = generate_auth_token(user=current_user, params=dict(request.args), expires=expires_seconds)
    ascii_token = token.decode('ascii')
    return jsonify({'token': ascii_token})


@app.route('/uua/<token>', methods=['GET', 'POST'])
def upgrade_user_account(token):
    """Allow a user to set a password for their account"""
    try:
        password = encrypt_password(request.form['password'])
    except KeyError:
        abort(412)
    try:
        decrypted_token = decrypt_token(str(token))
    except SignatureExpired:
        abort(401, 'Token expired')
    except BadSignature:
        abort(401, 'Token incorrect')
    user_collection = DBM.get_collection('user')
    user = x1_user_loader(decrypted_token['user_id'])
    user_collection.update({'_id': user['_id']}, {'$set': {'password': password, 'active': True, 'activated_at': datetime.datetime.now()}})
    db_session = x1cursor.mysql_session()
    _sql_user = db_session.query(tables.User).filter_by(mongo_id=user['_id']).update({
        "active": 1,
        "password": password,
        "activated_at": datetime.datetime.now()
    })
    db_session.flush()

    try:
        user_object = USER_DATASTORE.get_user(user['_id'])
    except StandardError:
        pass
    else:
        update_md5_password(request.form['password'], user_object)
        send_welcome_email(db_session.query(tables.User).filter_by(mongo_id=user['_id']).first(), db_session)
        login_user(user_object)

    response = app.make_response('')
    response.status_code = 200
    return response


@app.route('/activate-account/<token>', methods=['GET', 'POST'])
def activate_user_account(token):
    """Allow a user to activate their simple account"""
    try:
        decrypted_token = decrypt_token(str(token))
    except SignatureExpired:
        invalid_token = False
        expired_token = True
    except BadSignature:
        invalid_token = True
        expired_token = False
    else:
        invalid_token = False
        expired_token = False

    try:
        user = x1_user_loader(decrypted_token['user_id'])
    except UnboundLocalError:
        user_name = ''
        user_email = ''
    else:
        user_name = user['name']
        user_email = user['email']
    kwargs = {
        'env': request.environ,
        'user_name': user_name,
        'user_email': user_email,
        'token': token,
        'invalid_token': invalid_token,
        'expired_token': expired_token
    }

    try:
        html = render_template('security/activate_account.html', **kwargs)
    except StandardError:
        if x1utils.dev_server():
            raise

    return html


@app.route('/email_check')
def check_if_email_address_used():
    """Check if the email address already has an account"""
    try:
        email_address = request.args['email_address']
    except StandardError:
        abort(422, 'No email address submitted')

    if '|' in email_address:
        abort(422, 'Pipe not allowed')

    user_collection = DBM.get_collection('user')
    user_cursor = user_collection.find({
        'email': re.compile('^{email}$'.format(email=email_address.encode('utf8')), re.IGNORECASE),
        "$or": [{
            "active": False
        }, {
            "active": 0
        }, {
            "active": None
        }]
    })

    if user_cursor.count():
        # user has a "dummy" account
        _user = user_cursor.next()
        user_record = x1_user_loader(user_id=_user['_id'])
        token = generate_auth_token(user=user_record)
        try:
            _send_activation_email(destination_address=user_record['email'], token=token)
        except StandardError:
            raise
        else:
            response = app.make_response(
                'Email address has been used for an application.  Please check your email inbox to activate your account.')
            response.status_code = 201
            return response
    else:
        response = app.make_response('No user found.')
        response.status_code = 200
        return response


def _send_activation_email(destination_address, token):
    """Format the arguments and send an email"""
    msg = None
    html_content = None
    kwargs = {'upgrade_account_link': token, 'user': {'email': destination_address}, 'env': request.environ}
    html_content = x1utils.asciify(x1utils.render_email_template('security/email/account-activation.html', data_vars=kwargs))
    msg = MIMEText(html_content, 'html')

    msg['Subject'] = 'Account Activation for {site}'.format(site=request.environ['x1sitename'])

    if x1utils.dev_server():
        from_address = formataddr((str(Header('x1Jobs Dev', 'utf-8')), 's1broadband@gmail.com'))
    else:
        try:
            from_address = formataddr((str(Header(request.environ['x1sitename'],
                                                  'utf-8')), 'servicedesk@{site}.com'.format(site=request.environ['x1sitename'])))
        except KeyError:
            from_address = formataddr((str(Header('any1jobs', 'utf-8')), 'servicedesk@any1jobs.com'))

    msg['From'] = from_address
    msg['To'] = destination_address

    msg = x1utils.add_message_id_header(message=msg,
                                        regional_site=request.environ['x1sitename'],
                                        message_type='account_activation',
                                        identifier=destination_address.encode('utf8'))

    msg_as_string = msg.as_string()
    full_smtp_output = []
    full_smtp_output = x1utils.send_mail_by_smtp(from_address, destination_address.encode('utf8'), msg_as_string)

    return full_smtp_output


@app.route('/ucp/<regex("(.+)"):cv_id>')
@login_required
def get_user_cv_preview(cv_id):
    """Allows a user to preview their CV"""
    return file_get(cv_id, download=True)


def format_filename(filename):
    valid_chars = "-_.() %s%s" % (string.ascii_letters, string.digits)
    filename = ''.join(char for char in filename if char in valid_chars)
    filename = filename.replace(' ', '_').lower()
    return filename


@app.route('/createcv')
@login_required
def create_user_cv():
    """Creates a CV from a job profile"""

    session = x1cursor.mysql_session()

    user_record = session.query(tables.User).filter_by(email=current_user.email).first()
    user_profile = session.query(tables.Profile).filter_by(user_id=user_record.id).first()
    core_skill = session.query(tables.ProfileCoreSkill).filter_by(profile_id=user_profile.id).all()
    specialism = session.query(tables.ProfileSpecialism).filter_by(profile_id=user_profile.id).all()
    user_profile_work_experience = session.query(tables.ProfileWorkExperience).filter_by(profile_id=user_profile.id, _deleted=None).all()
    user_profile_education = session.query(tables.ProfileEducation).filter_by(profile_id=user_profile.id, _deleted=None).all()

    profile_extras_qualifications = []
    profile_extras_work = []

    if not user_profile:
        abort(400, 'No user profile found')
    for profile in user_profile_work_experience:
        profile_extras_work.append(profile.to_dict())
    for profile in user_profile_education:
        profile_extras_qualifications.append(profile.to_dict())

    user_profile = user_profile.to_dict()
    user_profile['core_skills'] = []
    for skill in core_skill:
        user_profile['core_skills'].append(skill.core_skill.core_skill)
    for skill in specialism:
        user_profile['core_skills'].append(skill.specialism.specialism)
    profile_extras_qualifications.reverse()
    profile_extras_work.reverse()
    kwargs = {
        'env': request.environ,
        'user': user_record.to_dict(),
        'profile': user_profile,
        'profile_extras_qualifications': profile_extras_qualifications,
        'profile_extras_work': profile_extras_work
    }
    print "JAY"
    html = render_template('ui/dist/js/app/templates/cv_template.html', **kwargs)
    print "NO"
    htmldoc = subprocess.Popen([
        '/usr/bin/htmldoc', '-t', 'pdf14', '--no-strict', '--continuous', '--no-title', '--no-toc', '--left', '2cm', '--right', '2cm',
        '--bottom', '2cm', '--header', '', '--footer', '', '--bodyfont', 'helvetica', '--textfont', 'helvetica', '--fontsize', '11px',
        '--size', 'a4', '--no-numbered', '-'
    ],
                               stdin=subprocess.PIPE,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)
    html = html.encode('ascii', 'ignore')
    pdf_file = htmldoc.communicate(html)[0]

    found_career_cv = None
    sql_user = load_user(_id=str(current_user.id), session=session)
    for cv_file in sql_user.files:
        if cv_file.career_profile_cv == 1:
            found_career_cv = cv_file

    if current_user.name:
        cvfilename = format_filename(current_user.name) + "_career_profile_cv.pdf"
    else:
        cvfilename = "career_profile_cv.pdf"

    if not found_career_cv:
        live_status = _get(tables.ProductStatus, session, status='live')
        site = _get(tables.Sites, session=session, site_url='https://www.{0}.com'.format(request.environ['x1sitename']))
        found_career_cv = tables.Files(status_id=live_status.id,
                                       friendly_name="Career Profile CV",
                                       filename=cvfilename,
                                       site_id=site.site_id,
                                       user_id=sql_user.id,
                                       career_profile_cv=1)
    else:
        found_career_cv._updated = datetime.datetime.now()

    session.add(found_career_cv)
    session.flush()

    file_dir = os.path.join(config.get('x1portal', 'cvs_base_dir'), str(found_career_cv.user_id), str(found_career_cv.id))
    file_path = os.path.join(file_dir, found_career_cv.filename)
    try:
        os.makedirs(file_dir)
    except OSError as e:
        print "OSError: {0}".format(e)

    with open(file_path, mode='w+b') as cv_file:
        cv_file.write(pdf_file)
    process_cv(sql_user.id, "add")
    return jsonify({"_id": found_career_cv.id, "_updated": convert_date_to_mongo(found_career_cv._updated)})


@app.route('/preview-career-profile-cv')
@login_required
def preview_user_cv():
    """Allow a user to preview their cv"""

    session = x1cursor.mysql_session()

    user_record = session.query(tables.User).filter_by(email=current_user.email).first()
    user_profile = session.query(tables.Profile).filter_by(user_id=user_record.id).first()
    user_profile_work_experience = session.query(tables.ProfileWorkExperience).filter_by(profile_id=user_profile.id, _deleted=None).all()
    user_profile_education = session.query(tables.ProfileEducation).filter_by(profile_id=user_profile.id, _deleted=None).all()
    profile_extras_qualifications = []
    profile_extras_work = []

    if not user_profile:
        abort(400, 'No user profile found')
    for profile in user_profile_work_experience:
        profile_extras_work.append(profile.to_dict())
    for profile in user_profile_education:
        profile_extras_qualifications.append(profile.to_dict())
    profile_extras_qualifications.reverse()
    profile_extras_work.reverse()

    kwargs = {
        'env': request.environ,
        'user': user_record.to_dict(),
        'profile': user_profile.to_dict(),
        'profile_extras_qualifications': profile_extras_qualifications,
        'profile_extras_work': profile_extras_work
    }
    try:
        html = render_template('ui/dist/js/app/templates/cv_template.html', **kwargs)
        htmldoc = subprocess.Popen([
            '/usr/bin/htmldoc', '-t', 'pdf14', '--no-strict', '--continuous', '--no-title', '--no-toc', '--left', '2cm', '--right', '2cm',
            '--bottom', '2cm', '--header', '', '--footer', '', '--fontsize', '11px', '--size', 'a4', '--no-numbered', '-'
        ],
                                   stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
        html = html.encode('utf-8', 'ignore')
        mypdf = htmldoc.communicate(html)

        if current_user.name:
            cvfilename = format_filename(current_user.name) + "_career_profile_cv.pdf"
        else:
            cvfilename = "career_profile_cv.pdf"

        response = flask.Response(mypdf, mimetype="application/pdf")
        response.headers['Content-Disposition'] = 'filename=' + cvfilename

    except StandardError:
        if x1utils.dev_server():
            response = "Sorry, template error: {e}".format(e=str(sys.exc_info()))
        else:
            response = r'<!--fail-->'
    return response


@app.route('/profile', methods=['GET'])
def get_profile():
    """GET profile data for a given user"""
    session = x1cursor.mysql_session()
    if current_user.is_anonymous:
        abort(403, 'User must login first')
    user_record = session.query(tables.User).filter_by(email=current_user.email).first()
    if not user_record:
        abort(400, 'No user found')
    user_profile = session.query(tables.Profile).filter_by(user_id=user_record.id).first()
    user_profile_work_experience = []
    profile_core_skill = []
    profile_specialism = []
    if user_profile:
        user_profile_work_experience = session.query(tables.ProfileWorkExperience).filter_by(profile_id=user_profile.id).all()
        profile_core_skill = session.query(tables.ProfileCoreSkill).filter_by(profile_id=user_profile.id).all()
        profile_specialism = session.query(tables.ProfileSpecialism).filter_by(profile_id=user_profile.id).all()

    core_skill_list = []
    for skill in profile_core_skill:
        core_skill_list.append(skill.core_skill.core_skill)
    for skill in profile_specialism:
        core_skill_list.append(skill.specialism.specialism)
    core_skill = ','.join(core_skill_list)

    first_job = 1
    if user_profile_work_experience:
        first_job = 0

    profile_dict = {}
    if user_profile:
        profile_dict['full_name'] = user_record.name
        profile_dict['email_address'] = user_record.email
        profile_dict['saved_on'] = user_record.saved_on
        profile_dict['user'] = {}
        profile_dict['user']['email'] = user_record.email
        profile_dict['user']['name'] = user_record.name
        profile_dict['user']['id'] = user_record.id

        profile_dict['desired_job_title'] = user_profile.desired_job_title
        profile_dict['part_time'] = user_profile.part_time
        profile_dict['full_time'] = user_profile.full_time
        profile_dict['contract'] = user_profile.contract
        if user_profile.available_immediately:
            profile_dict['immediate_availability'] = 'yes'
        if user_profile.available_immediately == 0:
            profile_dict['immediate_availability'] = 'no'
        profile_dict['desired_salary'] = user_profile.desired_salary
        profile_dict['preferred_location'] = ''
        profile_dict['driving'] = user_profile.driving
        profile_dict['evening'] = 0
        profile_dict['morning'] = 0
        profile_dict['weekends'] = 0
        profile_dict['afternoon'] = 0
        profile_dict['nightshift'] = 0
        profile_dict['unemployed'] = 0
        profile_dict['graduate'] = user_profile.graduate
        profile_dict['permanent'] = user_profile.permanent
        profile_dict['employed'] = user_profile.employed
        profile_dict['phone_number'] = user_record.phone_number
        profile_dict['thirdparty_optin'] = 'no'
        profile_dict['available_immediately'] = user_profile.available_immediately
        profile_dict['preferred_core_skills'] = []
        profile_dict['marketing_optin'] = 'no'
        profile_dict['profile_description'] = user_profile.profile_description
        profile_dict['address'] = user_profile.address_1
        profile_dict['cvdb_optin'] = 'no'
        profile_dict['_updated'] = user_profile._updated
        profile_dict['request_cvnow_review'] = 'no'
        profile_dict['first_job'] = first_job
        profile_dict['_created'] = user_profile._created
        profile_dict['_id'] = user_profile.id
        profile_dict['_etag'] = user_profile._etag

        profile_dict['core_skills'] = core_skill

        profile_dict['_links'] = {}
        profile_dict['_links']['self'] = {}
        profile_dict['_links']['self']['href'] = 'Profile'
        profile_dict['_links']['self']['title'] = 'Profile'

    return_data = {}
    return_data['_items'] = []
    return_data['_items'].append(profile_dict)

    return_data['_links'] = {}
    return_data['_links']['self'] = {}
    return_data['_links']['self']['href'] = 'Profile'
    return_data['_links']['self']['title'] = 'Profile'
    return_data['_links']['parent'] = {}
    return_data['_links']['parent']['href'] = '/'
    return_data['_links']['parent']['title'] = 'home'

    return_data['_meta'] = {}
    return_data['_meta']['max_results'] = 20
    return_data['_meta']['total'] = 1
    return_data['_meta']['page'] = 1

    return jsonify(return_data)


@app.route('/profile/<profile_id>', methods=['PATCH'])
def update_profile(profile_id=None):
    """PATCH profile data for a given user"""
    print "in here"
    session = x1cursor.mysql_session()
    user_record = session.query(tables.User).filter_by(email=current_user.email).first()
    if not user_record:
        abort(400, 'No user found')
    try:
        req = request.get_json()
    except StandardError:
        abort(400, "JSON not provided")

    core_skill_list = []
    specialism_list = []
    if req.get('core_skills'):
        job_type_code_list = req.get('core_skills').split(',')
        for skill in job_type_code_list:
            core_skill = session.query(tables.CoreSkill).filter_by(core_skill=skill).first()
            if core_skill:
                core_skill_list.append(core_skill.id)
                continue
            specialism = session.query(tables.Specialism).filter_by(specialism=skill).first()
            if specialism:
                specialism_list.append(specialism.id)

    user_profile = session.query(tables.Profile).filter_by(user_id=user_record.id).first()
    if not user_profile:
        user_profile = tables.Profile(user_id=user_record.id,
                                      address_1=req.get('address'),
                                      desired_job_title=req.get('desired_job_title'),
                                      desired_salary=req.get('desired_salary'),
                                      profile_description=req.get('profile_description'),
                                      employed=req.get('employed', 0),
                                      graduate=req.get('graduate', 0),
                                      available_immediately=req.get('available_immediately'),
                                      full_time=req.get('full_time', 0),
                                      part_time=req.get('part_time', 0),
                                      contract=req.get('contract', 0),
                                      permanent=req.get('permanent'),
                                      driving=req.get('driving'))
        session.add(user_profile)

        user_record.phone_number = req.get('phone_number')
        session.add(user_record)
        session.flush()

        for item in core_skill_list:
            profile_core_skill = tables.ProfileCoreSkill(profile_id=user_profile.id, core_skill_id=item)
            session.add(profile_core_skill)
        for item in specialism_list:
            profile_specialism = tables.ProfileSpecialism(profile_id=user_profile.id, specialism_id=item)
            session.add(profile_specialism)
        session.flush()
    else:
        user_profile.address_1 = req.get('address')
        user_profile.desired_job_title = req.get('desired_job_title')
        user_profile.desired_salary = req.get('desired_salary')
        user_profile.profile_description = req.get('profile_description')
        user_profile.employed = req.get('employed', 0)
        user_profile.graduate = req.get('graduate', 0)
        if req.get('available_immediately'):
            user_profile.available_immediately = req.get('available_immediately')
        if req.get('immediate_availability') and req.get('immediate_availability') == 'yes':
            user_profile.available_immediately = 1
        user_profile.full_time = req.get('full_time', 0)
        user_profile.part_time = req.get('part_time', 0)
        user_profile.contract = req.get('contract', 0)
        user_profile.permanent = req.get('permanent')
        user_profile.driving = req.get('driving')
        session.add(user_profile)

        user_record.phone_number = req.get('phone_number')
        session.add(user_record)

        #Delete all core skills, and then readd them.
        core_skill = session.query(tables.ProfileCoreSkill).filter_by(profile_id=user_profile.id).all()
        for item in core_skill:  #Delete all
            session.delete(item)
        for item in core_skill_list:  #Readd them
            profile_core_skill = tables.ProfileCoreSkill(profile_id=user_profile.id, core_skill_id=item)
            session.add(profile_core_skill)
        #Delete all specialism, and then readd them.
        specialism = session.query(tables.ProfileSpecialism).filter_by(profile_id=user_profile.id).all()
        for item in specialism:  #Delete all
            session.delete(item)
        for item in specialism_list:  #Readd
            profile_specialism = tables.ProfileSpecialism(profile_id=user_profile.id, specialism_id=item)
            session.add(profile_specialism)

        session.flush()

    return_data = {}
    return_data['_updated'] = user_profile._updated
    return_data['_created'] = user_profile._created
    return_data['_status'] = "OK"
    return_data['_id'] = user_profile.id
    return_data['_etag'] = user_profile._etag

    return_data['_links'] = {}
    return_data['_links']['self'] = {}
    return_data['_links']['self']['href'] = 'Profile'
    return_data['_links']['self']['title'] = 'Profile'

    return jsonify(return_data)


@app.route('/profile', methods=['POST'])
def store_profile():
    """POST profile data for a given user"""
    session = x1cursor.mysql_session()
    user_record = session.query(tables.User).filter_by(email=current_user.email).first()
    if not user_record:
        abort(400, 'No user found')
    try:
        req = request.get_json()
    except StandardError:
        abort(400, "JSON not provided")

    user_profile = session.query(tables.Profile).filter_by(user_id=user_record.id).first()
    immediate_availability = 0
    if 'immediate_availability' in req:
        if req.get('immediate_availability') == 'yes':
            immediate_availability = 1
    if not user_profile:
        user_profile = tables.Profile(user_id=user_record.id, available_immediately=immediate_availability)
        session.add(user_profile)
        session.flush()
    else:
        user_profile.available_immediately = immediate_availability
        session.add(user_profile)
        session.flush()

    return_data = {}
    return_data['_updated'] = user_profile._updated
    return_data['_created'] = user_profile._created
    return_data['_status'] = "OK"
    return_data['_id'] = user_profile.id
    return_data['_etag'] = user_profile._etag

    return_data['_links'] = {}
    return_data['_links']['self'] = {}
    return_data['_links']['self']['href'] = 'Profile'
    return_data['_links']['self']['title'] = 'Profile'

    return jsonify(return_data)


@app.route('/profile_extra', methods=['GET'])
def get_profile_extra():
    """GET profile extra data for a given user"""

    session = x1cursor.mysql_session()

    user_record = session.query(tables.User).filter_by(email=current_user.email).first()
    if not user_record:
        abort(400, 'No user found')
    user_profile = session.query(tables.Profile).filter_by(user_id=user_record.id).first()
    user_profile_work_experience = []
    user_profile_education = []
    if user_profile:
        user_profile_work_experience = session.query(tables.ProfileWorkExperience).filter_by(profile_id=user_profile.id,
                                                                                             _deleted=None).all()
        user_profile_education = session.query(tables.ProfileEducation).filter_by(profile_id=user_profile.id, _deleted=None).all()

    return_data = {}
    return_data['_items'] = []

    for experience in user_profile_work_experience:
        still_working = 0
        if not experience.job_ended:
            still_working = 1
        job_ended = None
        if experience.job_ended:
            job_ended = experience.job_ended.strftime("%B %Y")
        job_started = None
        if experience.job_started:
            job_started = experience.job_started.strftime("%B %Y")
        profile_dict = {}
        profile_dict['_updated'] = experience._updated
        profile_dict['extra_type'] = 'work'
        profile_dict['job_started'] = job_started
        profile_dict['job_ended'] = job_ended
        profile_dict['still_working'] = still_working
        profile_dict['company_name'] = experience.company_name
        profile_dict['job_description'] = experience.job_description
        profile_dict['_etag'] = experience._etag
        profile_dict['_created'] = experience._created
        profile_dict['_id'] = experience.id
        profile_dict['job_title'] = experience.job_title
        profile_dict['saved_on'] = user_record.saved_on

        profile_dict['user'] = {}
        profile_dict['user']['email'] = user_record.email
        profile_dict['user']['name'] = user_record.name
        profile_dict['user']['id'] = user_record.id

        profile_dict['_links'] = {}
        profile_dict['_links']['self'] = {}
        profile_dict['_links']['self']['href'] = 'ProfileExtra'
        profile_dict['_links']['self']['title'] = 'Profileextra'

        return_data['_items'].append(profile_dict)

    for education in user_profile_education:
        school_started = None
        if education.school_started:
            school_started = education.school_started.strftime("%B %Y")
        school_ended = None
        if education.school_ended:
            school_ended = education.school_ended.strftime("%B %Y")
        profile_dict = {}
        profile_dict['_updated'] = education._updated
        profile_dict['extra_type'] = 'qualification'
        profile_dict['school_started'] = school_started
        profile_dict['school_ended'] = school_ended
        profile_dict['school'] = education.school
        profile_dict['degree'] = education.degree
        profile_dict['grade'] = education.grade
        profile_dict['subject'] = education.subject
        profile_dict['current_studies'] = education.current_studies
        profile_dict['_created'] = education._created
        profile_dict['_id'] = education.id
        profile_dict['_etag'] = education._etag
        profile_dict['saved_on'] = user_record.saved_on

        profile_dict['user'] = {}
        profile_dict['user']['email'] = user_record.email
        profile_dict['user']['name'] = user_record.name
        profile_dict['user']['id'] = user_record.id

        profile_dict['_links'] = {}
        profile_dict['_links']['self'] = {}
        profile_dict['_links']['self']['href'] = 'ProfileExtra'
        profile_dict['_links']['self']['title'] = 'Profileextra'

        return_data['_items'].append(profile_dict)

    return_data['_links'] = {}
    return_data['_links']['self'] = {}
    return_data['_links']['self']['href'] = 'Profile'
    return_data['_links']['self']['title'] = 'Profile'
    return_data['_links']['parent'] = {}
    return_data['_links']['parent']['href'] = '/'
    return_data['_links']['parent']['title'] = 'home'

    return_data['_meta'] = {}
    return_data['_meta']['max_results'] = 20
    return_data['_meta']['total'] = 1
    return_data['_meta']['page'] = 1

    return jsonify(return_data)


@app.route('/profile_extra/<profile_extra_id>', methods=['PATCH'])
def update_profile_extra(profile_extra_id=None):
    """PATCH profile extra data for a given user"""
    session = x1cursor.mysql_session()
    user_record = session.query(tables.User).filter_by(email=current_user.email).first()
    if not user_record:
        abort(400, 'No user found')
    try:
        req = request.get_json()
    except StandardError:
        abort(400, "JSON not provided")

    user_profile = session.query(tables.Profile).filter_by(user_id=user_record.id).first()
    if not user_profile:
        abort(400, 'No user profile')

    #DELETE Education entry
    if req.get('deleted') and req.get('extra_type') == "qualification":
        user_profile_education = session.query(tables.ProfileEducation).filter_by(id=req.get('_id')).first()
        if not user_profile_education.profile.user_id == user_record.id:
            abort(403, "User cannot update profile that they don't own")
        user_profile_education._deleted = datetime.datetime.now()
        session.add(user_profile_education)

    #DELETE Work entry
    if req.get('deleted') and req.get('extra_type') == "work":
        user_profile_work = session.query(tables.ProfileWorkExperience).filter_by(id=req.get('_id')).first()
        if not user_profile_work.profile.user_id == user_record.id:
            abort(403, "User cannot update profile that they don't own")
        user_profile_work._deleted = datetime.datetime.now()
        session.add(user_profile_work)

    #UPDATE Education entry
    if not req.get('deleted') and req.get('extra_type') == "qualification":
        school_started = None
        if req.get('school_started'):
            school_started = datetime.datetime.strptime(req.get('school_started'), "%B %Y")
        school_ended = None
        if req.get('school_ended'):
            school_ended = datetime.datetime.strptime(req.get('school_ended'), "%B %Y")
        user_profile_education = session.query(tables.ProfileEducation).filter_by(id=req.get('_id')).first()
        if not user_profile_education.profile.user_id == user_record.id:
            abort(403, "User cannot update profile that they don't own")
        user_profile_education.current_studies = req.get('current_studies')
        user_profile_education.degree = req.get('degree')
        user_profile_education.grade = req.get('grade')
        user_profile_education.school = req.get('school')
        user_profile_education.school_ended = school_ended
        user_profile_education.school_started = school_started
        user_profile_education.subject = req.get('subject')
        session.add(user_profile_education)

    #UPDATE Work entry
    if not req.get('deleted') and req.get('extra_type') == "work":
        job_started = None
        if req.get('job_started'):
            job_started = datetime.datetime.strptime(req.get('job_started'), "%B %Y")
        job_ended = None
        if req.get('job_ended'):
            job_ended = datetime.datetime.strptime(req.get('job_ended'), "%B %Y")
        user_profile_work = session.query(tables.ProfileWorkExperience).filter_by(id=req.get('_id')).first()
        if not user_profile_work.profile.user_id == user_record.id:
            abort(403, "User cannot update profile that they don't own")
        user_profile_work.company_name = req.get('company_name')
        user_profile_work.job_description = req.get('job_description')
        user_profile_work.job_title = req.get('job_title')
        user_profile_work.still_working = req.get('still_working')
        user_profile_work.job_ended = job_ended
        user_profile_work.job_started = job_started
        session.add(user_profile_work)

    session.flush()

    return_data = {}
    return_data['_updated'] = user_profile._updated
    return_data['_created'] = user_profile._created
    return_data['_status'] = "OK"
    return_data['_id'] = profile_extra_id
    return_data['_etag'] = user_profile._etag

    return_data['_links'] = {}
    return_data['_links']['self'] = {}
    return_data['_links']['self']['href'] = 'ProfileExtra'
    return_data['_links']['self']['title'] = 'ProfileExtra'

    return jsonify(return_data)


@app.route('/profile_extra', methods=['POST'])
def store_profile_extra():
    """POST profile extra data for a given user"""
    session = x1cursor.mysql_session()
    user_record = session.query(tables.User).filter_by(email=current_user.email).first()
    if not user_record:
        abort(400, 'No user found')
    try:
        req = request.get_json()
    except StandardError:
        abort(400, "JSON not provided")
    user_profile = session.query(tables.Profile).filter_by(user_id=user_record.id).first()
    if not user_profile:
        abort(400, 'No user profile')

    #POST Education entry
    if req.get('extra_type') == "qualification":
        school_started = None
        if req.get('school_started'):
            school_started = datetime.datetime.strptime(req.get('school_started'), "%B %Y")
        school_ended = None
        if req.get('school_ended'):
            school_ended = datetime.datetime.strptime(req.get('school_ended'), "%B %Y")
        user_profile_education = tables.ProfileEducation(profile_id=user_profile.id,
                                                         current_studies=req.get('current_studies'),
                                                         degree=req.get('degree'),
                                                         grade=req.get('grade'),
                                                         school=req.get('school'),
                                                         school_ended=school_ended,
                                                         school_started=school_started,
                                                         subject=req.get('subject'))
        session.add(user_profile_education)

    #POST Work entry
    if req.get('extra_type') == "work":
        job_started = None
        if req.get('job_started'):
            job_started = datetime.datetime.strptime(req.get('job_started'), "%B %Y")
        job_ended = None
        if req.get('job_ended'):
            job_ended = datetime.datetime.strptime(req.get('job_ended'), "%B %Y")
        user_profile_work = tables.ProfileWorkExperience(profile_id=user_profile.id,
                                                         company_name=req.get('company_name'),
                                                         job_description=req.get('job_description'),
                                                         job_title=req.get('job_title'),
                                                         job_ended=job_ended,
                                                         job_started=job_started)
        session.add(user_profile_work)
        #need to add still_working to db and accept it

    session.flush()

    return_data = {}
    return_data['_updated'] = user_profile._updated
    return_data['_created'] = user_profile._created
    return_data['_status'] = "OK"
    if req.get('extra_type') == "work":
        return_data['_id'] = user_profile_work.id
        return_data['_etag'] = user_profile_work._etag
    if req.get('extra_type') == "qualification":
        return_data['_id'] = user_profile_education.id
        return_data['_etag'] = user_profile_education._etag

    return_data['_links'] = {}
    return_data['_links']['self'] = {}
    return_data['_links']['self']['href'] = 'ProfileExtra'
    return_data['_links']['self']['title'] = 'ProfileExtra'

    return jsonify(return_data)


@app.route('/<regex("(cookies|terms|privacy|recruiters|sitemap|help|signin|cv1services)"):pagewanted>')
def footer_pages(pagewanted):
    """Returns most footer pages"""
    kwargs = {'env': request.environ, 'enabled_websites': enabled_websites()}

    try:
        html = render_template('{f}.html'.format(f=pagewanted), **kwargs)
    except StandardError:
        if x1utils.dev_server():
            html = "Sorry, template error: {e}".format(e=str(sys.exc_info()))
        else:
            html = r'<!--fail-->'

    return html


@app.route('/alg')
def get_automatic_login_token():
    """
    Given a user id, generate a short-lived token which can be used to log in as that user.
    Return the token within a JSON structure.
    """
    try:
        incoming_user_id = request.args.get('u')
    except StandardError:
        return abort(404)

    login_url = '/ali{logintoken}'.format(
        logintoken=generate_auth_token(user={'id': incoming_user_id}, include_session=False, expires=60, params={'url': '/settings'}))

    return jsonify({"status": "OK", "url": login_url})


@app.route('/ali<regex("(.+)"):autologintoken>')
def automatic_login(autologintoken):
    """Allow for user to auto login from email alert"""
    try:
        login_params = decrypt_token(autologintoken)
        user_id = login_params['user_id']
        url_path = login_params['params']['url']
        if user_id.isdigit():
            #This is a SQL user record. We need to get the MongoID.
            db_session = x1cursor.mysql_session()
            user = db_session.query(tables.User).filter_by(id=user_id).first()
            if user:
                user_id = user.mongo_id
        user = USER_DATASTORE.get_user(user_id)
        if not user:
            return abort(404)
    except StandardError:
        return abort(404)

    login_user(user)

    protocol = request.environ['x1httporhttps']
    domain = request.environ['x1domainname']

    if x1utils.dev_server():
        protocol = 'http'
        domain = re.sub(r'^www\.(.+)\.com', r'local-dev.\1.com', domain)

    url = '{h}://{d}{u}'.format(h=protocol, d=domain, u=url_path)
    return redirect(url, code=302)


def get_homepage_count(regional_site=None):
    """Gets the count of jobs for the current site"""
    db_session = x1cursor.mysql_session()
    if not regional_site:
        regional_site = db_session.query(
            tables.Sites).filter_by(site_url='https://www.{0}.com'.format(request.environ['x1sitename'])).first()
    if request.environ['x1sitename'] == 's1jobs':
        national_locations = _get(tables.NationalLocations, session=db_session, location_name='Scotland', cacheable=False)
    else:
        national_locations = _get(tables.NationalLocations, session=db_session, location_name='England and Wales', cacheable=False)
    search_structure = {
        "fq":
            'WebRegionalSite:{0}.com OR national_location_id:{1}'.format(regional_site.site_name, national_locations.national_location_id),
        "version":
            2.2,
        "wt":
            "json",
        "start":
            0,
        "rows":
            0,
        "sort":
            '_sort_priority asc, _id desc',
        "q":
            '*:*',
        "fl":
            '_id,score,*'
    }
    result = x1jobsearchresultset.post_to_solr(search_structure)
    total_results = result['response']['numFound']

    return total_results


@app.route('/')
def homepage():
    """Returns the homepage"""
    if config.getboolean('cache', 'homepage_cache_global') and current_user.is_anonymous:
        cache_key = "homepage-not-signed-in-{web}".format(web=request.environ['x1sitename'])
        lock_key = cache_key + '_lock'
        cached_homepage = x1utils.return_cache_or_set_lock(cache_key, lock_key)
        if cached_homepage:
            return cached_homepage

    job_count = get_homepage_count()

    template_vars = {'env': request.environ, 'request': request, 'job_count': job_count, 'enabled_websites': enabled_websites()}

    # featured companies
    if config.get('homepage', 'max_homepage_featured_companies') > 0:
        template_vars['featured_companies'] = return_featured_companies()

    # XS-2119 - Seo Organisation Schema data
    dbschema = x1cursor.mongo().get_database(config.get('mongo', 'database')).get_collection('SeoSchema')
    template_vars['seo_schema'] = dbschema.find_one({"Site": request.environ['x1sitename']})

    # XS-1093 Dynamic SEO Links
    template_vars['seo_locations'] = x1searchresults.get_top_locations(request.environ['x1sitename'], 12)
    template_vars['seo_core_skills'] = x1searchresults.get_top_skills(request.environ['x1sitename'], 6)

    # going to the homepage also resets your 'current_search' to None
    # so that clicks on e.g. Featured Jobs don't include misleading previous/next
    session['current_search'] = {}

    try:
        html_content = render_template('index.html', **template_vars)
    except StandardError:
        if x1utils.dev_server():
            html_content = "<code>Sorry, template error: {e}</code>".format(e=escapehtml(str(sys.exc_info())))
        else:
            raise

    if config.getboolean('homepage', 'homepage_minify'):
        try:
            minified_html = re.sub(r'[\r\n]+', '\n', re.sub(r'>[ \r\n\t]+<', '> <', html_content))
        except StandardError:
            pass
        else:
            html_content = minified_html

    if config.getboolean('cache', 'homepage_cache_global') and current_user.is_anonymous:
        if not x1utils.dev_server():
            try:
                x1cache.set(cache_key, pickle.dumps(html_content), config.getint('cache-times', 'cache_non_signedin_homepage_length'))
                x1cache.cache_delete(lock_key)
            except StandardError:
                pass

    return html_content


@app.route('/countypress')
def countypresshomepage():
    """Returns the homepage"""
    if config.getboolean('cache', 'homepage_cache_global') and current_user.is_anonymous:
        cache_key = "homepage-not-signed-in-countypress-{web}".format(web=request.environ['x1sitename'])
        lock_key = cache_key + '_lock'
        cached_homepage = x1utils.return_cache_or_set_lock(cache_key, lock_key)
        if cached_homepage:
            return cached_homepage

    job_count = get_homepage_count()

    template_vars = {'env': request.environ, 'request': request, 'job_count': job_count, 'enabled_websites': enabled_websites()}

    # featured companies
    if config.get('homepage', 'max_homepage_featured_companies') > 0:
        template_vars['featured_companies'] = return_featured_companies()

    # XS-2119 - Seo Organisation Schema data
    dbschema = x1cursor.mongo().get_database(config.get('mongo', 'database')).get_collection('SeoSchema')
    template_vars['seo_schema'] = dbschema.find_one({"Site": request.environ['x1sitename']})

    # XS-1093 Dynamic SEO Links
    template_vars['seo_locations'] = x1searchresults.get_top_locations(request.environ['x1sitename'], 12)
    template_vars['seo_core_skills'] = x1searchresults.get_top_skills(request.environ['x1sitename'], 6)

    # going to the homepage also resets your 'current_search' to None
    # so that clicks on e.g. Featured Jobs don't include misleading previous/next
    session['current_search'] = {}

    try:
        html_content = render_template('/countypress/index.html', **template_vars)
    except StandardError:
        if x1utils.dev_server():
            html_content = "<code>Sorry, template error: {e}</code>".format(e=escapehtml(str(sys.exc_info())))
        else:
            raise

    if config.getboolean('homepage', 'homepage_minify'):
        try:
            minified_html = re.sub(r'[\r\n]+', '\n', re.sub(r'>[ \r\n\t]+<', '> <', html_content))
        except StandardError:
            pass
        else:
            html_content = minified_html

    if config.getboolean('cache', 'homepage_cache_global') and current_user.is_anonymous:
        if not x1utils.dev_server():
            try:
                x1cache.set(cache_key, pickle.dumps(html_content), config.getint('cache-times', 'cache_non_signedin_homepage_length'))
                x1cache.cache_delete(lock_key)
            except StandardError:
                pass

    return html_content


@app.route('/cnjobs')
def cn1homepage():
    """Returns the homepage"""
    if config.getboolean('cache', 'homepage_cache_global') and current_user.is_anonymous:
        cache_key = "homepage-not-signed-in-cnjobs-{web}".format(web=request.environ['x1sitename'])
        lock_key = cache_key + '_lock'
        cached_homepage = x1utils.return_cache_or_set_lock(cache_key, lock_key)
        if cached_homepage:
            return cached_homepage

    job_count = get_homepage_count()

    template_vars = {'env': request.environ, 'request': request, 'job_count': job_count, 'enabled_websites': enabled_websites()}

    # featured companies
    if config.get('homepage', 'max_homepage_featured_companies') > 0:
        template_vars['featured_companies'] = return_featured_companies()

    # XS-2119 - Seo Organisation Schema data
    dbschema = x1cursor.mongo().get_database(config.get('mongo', 'database')).get_collection('SeoSchema')
    template_vars['seo_schema'] = dbschema.find_one({"Site": request.environ['x1sitename']})

    # XS-1093 Dynamic SEO Links
    template_vars['seo_locations'] = x1searchresults.get_top_locations(request.environ['x1sitename'], 12)
    template_vars['seo_core_skills'] = x1searchresults.get_top_skills(request.environ['x1sitename'], 6)

    # going to the homepage also resets your 'current_search' to None
    # so that clicks on e.g. Featured Jobs don't include misleading previous/next
    session['current_search'] = {}

    try:
        html_content = render_template('/cn1jobs/index.html', **template_vars)
    except StandardError:
        if x1utils.dev_server():
            html_content = "<code>Sorry, template error: {e}</code>".format(e=escapehtml(str(sys.exc_info())))
        else:
            raise

    if config.getboolean('homepage', 'homepage_minify'):
        try:
            minified_html = re.sub(r'[\r\n]+', '\n', re.sub(r'>[ \r\n\t]+<', '> <', html_content))
        except StandardError:
            pass
        else:
            html_content = minified_html

    if config.getboolean('cache', 'homepage_cache_global') and current_user.is_anonymous:
        if not x1utils.dev_server():
            try:
                x1cache.set(cache_key, pickle.dumps(html_content), config.getint('cache-times', 'cache_non_signedin_homepage_length'))
                x1cache.cache_delete(lock_key)
            except StandardError:
                pass

    return html_content


@app.route('/featured_company')
@cross_origin()
def get_newspaper_feat_companies():
    """Generate a json list of featured companies depending on the newspaper"""
    if 'domain' in request.args:
        domain = request.args['domain']
    else:
        domain = request.referrer or 'www.bournemouthecho.co.uk'

    if 'limit' in request.args:
        try:
            limit = int(float(request.args['limit']))
        except StandardError:
            limit = 100
    else:
        limit = 100

    cache_key = 'featured_companies_{newspaper}_{limit}'.format(newspaper=domain, limit=limit)
    cached_content = x1cache.get(cache_key)
    if cached_content:
        featured_companies = pickle.loads(cached_content)
        if x1utils.dev_server():
            print 'Returning cached content for newspaper: {newspaper}, limit: {limit}'.format(newspaper=domain, limit=limit)
        return flask.Response(featured_companies, status=200, mimetype='application/json')
    else:
        _db = x1cursor.mongo().get_database(config.get('mongo', 'database'))
        logo_collection = _db.get_collection('CompanyLogo')
        job_collection = _db.get_collection('Job')
        try:
            featured_companies = list(
                x1cursor.mysql(
                    """select * from newspaper_featured_company join newspaper_featured_company_sites using(featured_company_id)
                                                        join newspaper_sites using(site_id) join company using(company_id) where site_url = "{0}"
                                                        and date_from < NOW() and date_to > NOW()""", [domain]).fetchall())
        except StandardError:
            featured_companies = []
        companies_to_remove = list()
        for company in featured_companies:
            try:
                contact_id = re.compile('^{contactid}$'.format(contactid=company['contact_id']), re.IGNORECASE)
                if logo_collection.find({"contact_id": contact_id}).count() > 0:
                    company['CompanyImageURL'] = r'https://www.{environment}.com/igz/{company_id}'.format(
                        environment=request.environ['x1sitename'], company_id=company['contact_id'])
                else:
                    companies_to_remove.append(company)
                    continue

            except StandardError:
                companies_to_remove.append(company)
                continue

            job_count = job_collection.find({"CompanyName": company['company_name'], "validated": True, "job_is_expired": False}).count()
            company['live_jobs'] = job_count

        try:
            for company in companies_to_remove:
                featured_companies.remove(company)
        except NameError:
            pass  # Nothing to remove

        return_list = []
        for company in featured_companies:
            temp = {}
            temp["CompanyImageURL"] = company.get("CompanyImageURL")
            temp["live_jobs"] = company.get("live_jobs")
            temp["Company_Name"] = company.get('company_name')
            if temp not in return_list:
                return_list.append(temp)

        featured_companies = return_list[:limit]

        featured_companies = json.dumps(featured_companies)

        x1cache.set(cache_key, pickle.dumps(featured_companies), 7200)

        return flask.Response(featured_companies, status=200, mimetype='application/json')


def check_specialism(core_skill, specialism):
    """check if we have a an s1 specialism slug"""
    if core_skill in specialism:  #this is an s1 specialisms
        return specialism.replace('-' + core_skill, '')
    else:
        """either it's an x1 specialism slug or location slug
        that will be tested in the main method"""
        return specialism


def process_seo_slugs(slug1=None, slug2=None, slug3=None):
    """Allow s1 seo search urls to work"""
    core_skill = None
    specialism = None
    location = None
    distance = []
    core_skill_list = []
    keywords = []
    job_location_city = []
    slug_data = {}
    seo_link = []
    slug_exclusions = ['part-time']

    if slug1 and slug2 and slug3:
        #straightforward coreskill specialism and location
        seo_link.append('coreskill specialism location')
        core_skill = x1utils.get_core_skill_from_slug(slug1)
        specialism = x1utils.get_specialism_from_slug(check_specialism(slug1, slug2))
        location = x1utils.get_location_from_slug(slug3)
        if not location and slug3 not in slug_exclusions:
            keywords.append(slug3)
            slug_data['Keywords'] = keywords

    if slug2 and not slug3:
        """slug 1 could be a core skill or location and slug2
        can be a specialism or a location or part-time"""
        core_skill = x1utils.get_core_skill_from_slug(slug1)
        if core_skill:
            specialisms = x1utils.get_specialism_slug_list()
            specialism = check_specialism(slug1, slug2)
            if specialism not in specialisms:
                specialism = None
                location = x1utils.get_location_from_slug(slug2)
                if not location and slug2 not in slug_exclusions:
                    keywords.append(slug2)
                    slug_data['Keywords'] = keywords
                else:
                    seo_link.append('coreskill location')
            else:
                core_skills = x1utils.get_core_skills_slug_list()
                if slug1 in core_skills:
                    core_skill = x1utils.get_core_skill_from_slug(slug1)
                    if not core_skill and slug2 not in slug_exclusions:
                        keywords.append(slug2)
                        slug_data['Keywords'] = keywords
                    else:
                        specialism = x1utils.get_specialism_from_slug(check_specialism(slug1, slug2))
                        seo_link.append('coreskill specialism')
                else:
                    location = x1utils.get_location_from_slug(slug1)
                    if not location and slug2 not in slug_exclusions:
                        keywords.append(slug2)
                        slug_data['Keywords'] = keywords
        else:
            location = x1utils.get_location_from_slug(slug1)
            if slug2 not in slug_exclusions:
                keywords.append(slug2)
                slug_data['Keywords'] = keywords

    if slug1 and not slug2:
        #slug 1 can be a core skill or a location
        core_skills = x1utils.get_core_skills_slug_list()
        if slug1 in core_skills:
            core_skill = x1utils.get_core_skill_from_slug(slug1)
            if not core_skill and slug1 not in slug_exclusions:
                keywords.append(slug1)
                slug_data['Keywords'] = keywords
            else:
                seo_link.append('coreskill')
        else:
            location = x1utils.get_location_from_slug(slug1)
            if not location and slug1 not in slug_exclusions:
                keywords.append(slug1)
                slug_data['Keywords'] = keywords
            else:
                seo_link.append('location')

    if core_skill is not None:
        core_skill_list.append(core_skill)
        slug_data['CoreSkillList'] = core_skill_list

    if specialism is not None:
        spec_slug = x1utils.get_specialism_from_slug(specialism)
        if spec_slug:
            slug_data['SpecialismList'] = [spec_slug]
        else:
            slug_data['SpecialismList'] = [specialism]

    if location is not None:
        job_location_city.append(location)
        slug_data['JobLocation.City'] = job_location_city
    distance.append('20')
    slug_data['Distance'] = distance

    part_time_slug = [re.search("^.*part-time$", slug) for slug in [slug1, slug2, slug3] if slug]
    for item in part_time_slug:
        if item is not None:
            slug_data['FullOrPartTime'] = ['Part']

    return slug_data, seo_link


def get_region(site_id):
    db_session = x1cursor.mysql_session()
    query = db_session.query(tables.Region)
    region = query.filter_by(site_id=site_id).first().region
    return region


@app.route('/<string:s1_company_slug>--jobs')
def s1_company_redirect(s1_company_slug=None):

    s1_alias = "{0}--jobs".format(s1_company_slug)
    target_company_url = None

    cache_key = s1_alias
    cached_content = x1cache.get(cache_key)
    if cached_content:
        target_company_url = pickle.loads(cached_content)
    else:
        with open('scripts/dashdashjobsredirects.json') as json_file:
            data = json.load(json_file)
            for company_redirect in data['redirects']:
                if s1_alias in company_redirect:
                    target_company_url = company_redirect[s1_alias]
                    x1cache.set(cache_key, pickle.dumps(target_company_url), 86400)

    if target_company_url:
        return redirect('{proto}://{dom}/{path}'.format(proto='https', dom=request.environ['x1domainname'], path=target_company_url),
                        code=301)

    #redirect to a keyword search
    return redirect('{proto}://{dom}/{path}'.format(proto='https',
                                                    dom=request.environ['x1domainname'],
                                                    path='jobs/{0}'.format(s1_company_slug.replace('-', ' '))),
                    code=302)


def check_specialism_or_location_redirect(slug1, slug2):
    #slug 2 could be a specialism that needs fixed or
    # a location that might need redirected

    if slug2.endswith('-{slug1}'.format(slug1=slug1)):
        #its definitely a specialism that needs fixed
        slug_2_redirect = re.sub('-{slug1}$'.format(slug1=slug1), '', slug2)
        return slug_2_redirect
    else:
        #slug2 could be a location that needs a redirect, or
        #it could be one of the badly formatted specialisms
        location_redirect = x1utils.get_location_redirect_from_slug(slug2)
        if location_redirect is not None:
            return location_redirect
        else:  #check for the specialism
            specialism_redirect = x1utils.get_specialism_redirect_from_slug(slug2)
            if specialism_redirect is not None:
                return specialism_redirect


def get_redirect_for_old_url(slug1, slug2, slug3):

    # We need to convert old style urls to new style
    # old: https://www.s1jobs.com/jobs/<coreskill>/<specialism-coreskill>/
    # new: https://www.s1jobs.com/jobs/<coreskill>/<specialism>/
    # old: https://www.s1jobs.com/jobs/<coreskill>/<specialism-coreskill>/<location>
    # new: https://www.s1jobs.com/jobs/<coreskill>/<specialism>/<location>
    # we also need to deal with new location slugs - if the url has an old location slug
    # redirect to the new one.
    needs_redirect = False
    if slug1 is not None and slug2 is not None and slug3 is not None:
        #most likely a core_skill/specialism/location url

        slug1_lower = slug1.lower()
        slug2_lower = slug2.lower()
        slug3_lower = slug3.lower()

        cache_key = 'x1-redirect-url-{slug1}-{slug2}-{slug3}'.format(slug1=slug1_lower, slug2=slug2_lower, slug3=slug3_lower)
        cached_content = x1cache.get(cache_key)
        if cached_content:
            redirect_url = pickle.loads(cached_content)
            return redirect_url
        else:
            #check slug 3 location redirect or good location / keyword
            location_redirect = x1utils.get_location_redirect_from_slug(slug3_lower)
            if location_redirect is not None:
                slug3_lower = location_redirect
                needs_redirect = True

            slug2_redirect = check_specialism_or_location_redirect(slug1_lower, slug2_lower)
            if slug2_redirect:
                slug2_lower = slug2_redirect
                needs_redirect = True

            if needs_redirect:
                redirect_url = 'jobs/{slug1}/{slug2}/{slug3}/'.format(slug1=slug1_lower, slug2=slug2_lower, slug3=slug3_lower)
                x1cache.set(cache_key, pickle.dumps(redirect_url), 86400 * 7)
                return redirect_url

    if slug1 is not None and slug2 is not None and slug3 is None:
        #could be core_skill/specialism, core_skill/location,
        #core_skill/keyword or location/keyword
        slug1_lower = slug1.lower()
        slug2_lower = slug2.lower()

        cache_key = 'x1-redirect-url-{slug1}-{slug2}'.format(slug1=slug1_lower, slug2=slug2_lower)
        cached_content = x1cache.get(cache_key)
        if cached_content:
            redirect_url = pickle.loads(cached_content)
            return redirect_url
        else:
            #check slug2 to see if it needs fixed
            slug2_redirect = check_specialism_or_location_redirect(slug1_lower, slug2_lower)
            if slug2_redirect:
                slug2_lower = slug2_redirect
                needs_redirect = True
            else:
                #no change to slug2 it might be a keyword, so check slug1
                location_redirect = x1utils.get_location_redirect_from_slug(slug1_lower)
                if location_redirect is not None:
                    slug1_lower = location_redirect
                    needs_redirect = True

            if needs_redirect:
                redirect_url = 'jobs/{slug1}/{slug2}/'.format(slug1=slug1_lower, slug2=slug2_lower)
                x1cache.set(cache_key, pickle.dumps(redirect_url), 86400 * 7)
                return redirect_url

    if slug1 is not None and slug2 is None and slug3 is None:
        #core_skill or location
        slug1_lower = slug1.lower()
        cache_key = 'x1-redirect-url-{slug1}'.format(slug1=slug1_lower)
        cached_content = x1cache.get(cache_key)
        if cached_content:
            redirect_url = pickle.loads(cached_content)
            return redirect_url
        else:
            #if it's not a bad location there will be no need to redirect
            location_redirect = x1utils.get_location_redirect_from_slug(slug1_lower)
            if location_redirect is not None:
                redirect_url = 'jobs/{slug1}/'.format(slug1=location_redirect)
                x1cache.set(cache_key, pickle.dumps(redirect_url), 86400 * 7)
                return redirect_url


@app.route('/jobs/', strict_slashes=True)
@app.route('/jobs/<string:slug1>/', strict_slashes=True)
@app.route('/jobs/<string:slug1>/<string:slug2>/', strict_slashes=True)
@app.route('/jobs/<string:slug1>/<string:slug2>/<string:slug3>/', strict_slashes=True)
def search_results(seo_record=None, slug1=None, slug2=None, slug3=None):
    """Allow a user to search for jobs"""

    redirect_url = get_redirect_for_old_url(slug1, slug2, slug3)
    if redirect_url:
        return redirect('{proto}://{dom}/{path}'.format(proto='https', dom=request.environ['x1domainname'], path=redirect_url), code=301)

    request_args = dict(request.args)
    seo_link = None
    if slug1 is not None:
        #seo if there is seo content for that url
        slugs = [slug1, slug2, slug3]
        seo_url = '/'.join(filter(None, slugs))
        cache_key = 'x1-seo-url-{path}-{website}'.format(path=seo_url, website=request.environ['x1sitename'])
        cached_content = x1cache.get(cache_key)
        if cached_content:
            seo_record = pickle.loads(cached_content)
        else:
            db_session = x1cursor.mysql_session()
            query = db_session.query(tables.Sites)
            site_id = query.filter_by(site_name=request.environ['x1sitename']).first().site_id
            try:
                seo_record = db_session.query(tables.SeoContent).filter_by(alias="/jobs/{u}".format(u=seo_url), site_id=site_id).first()
                if seo_record:
                    x1cache.set(cache_key, pickle.dumps(seo_record), 7200)

            except StandardError as e:
                print e

        slug_data, seo_link = process_seo_slugs(slug1, slug2, slug3)
        for key in slug_data:
            request_args[key] = slug_data[key]

    # Abort if it's not a real search, or if it's greater than page 20
    if len(request_args.keys()) == 2 and 'sort' in request_args and 'page' in request_args:
        abort(404)

    if 'output_type' in request_args:
        output_type = str(request_args['output_type'][0])
        del request_args['output_type']
        try:
            newrelic.agent.disable_browser_autorum()
        except NameError:
            pass
    else:
        output_type = 'html'

    for key, item in request_args.iteritems():
        data = []
        for entry in item:
            if entry:
                try:
                    data.append(HTML_PARSER.unescape(_remove_p_tags(clean_html(item[0]))))
                except ParserError:
                    data.append(item[0])
        if data:
            request_args[key] = data
        else:
            request_args[key] = ['']

    # you can enter a single Gemstone-like VacancyID in the keywords box to jump direct to that job:
    if 'Keywords' in request_args:  # and request_args['Keywords'] != ['']:
        if re.search(r'^.[A-Z]....[0-9]...?(?:_\d_\d)?$', request_args['Keywords'][0]):
            job_collection = DBM.get_collection('Job')
            job_cursor = job_collection.find(
                {
                    "VacancyID": re.compile(r'^{k}$'.format(k=request_args['Keywords'][0])),
                    "validated": True,
                    "job_is_expired": False
                }, {"url": 1})
            if job_cursor.count():
                job = job_cursor.next()

                url = flask.url_for('jobDetailPage', seourl=job['url'][5:-9], vacancy_id_ext=job['url'][-8:])
                return redirect(url, code=302)

    try:
        session['total_searches'] += 1
    except KeyError:
        session['total_searches'] = 1

    if 'JobLocation.City' in request_args and request_args['JobLocation.City']:
        return x1searchresults.get_search_results(request_args,
                                                  returntype=output_type,
                                                  enabled_websites=enabled_websites(),
                                                  seo_record=seo_record,
                                                  seo_link=seo_link)
    return x1searchresults.get_search_results(request_args,
                                              returntype=output_type,
                                              enabled_websites=enabled_websites(),
                                              region=request.environ['x1sitename'],
                                              seo_record=seo_record,
                                              seo_link=seo_link)


@app.route('/job/<string:slug1>/<string:slug2>/<int:s1_vacancy_id>.html')
@app.route('/job/<string:slug1>/<string:slug2>/<string:slug3>/<int:s1_vacancy_id>.html')
def job_detail_page_s1(slug1=None, slug2=None, slug3=None, s1_vacancy_id=None):
    """Allows s1 frieindly job detail url to function"""

    try:
        vacancy = x1vacancy.x1vacancy(vacancy_id=str(s1_vacancy_id))
    except StandardError:
        abort(500)
    """it seems odd to get the vacancy object extract a parameter
       then manipulate that to send to another function which
       then grabs the vacancy object again. It saves code repetition though"""
    if not vacancy:
        abort(404, 'Not job match found in the db')
    replace_punctuation = string.maketrans(string.punctuation, ' ' * len(string.punctuation))  # create the thing to remove punctuation
    job_title_words = str(x1utils.asciify(x1utils.fix_charset(
        vacancy['JobTitle']))).lower().translate(replace_punctuation).split()  # remove punctuation, and split the job title
    job_title_words = [x for x in job_title_words if x not in ['and', 'amp', 'nbsp']]
    seoslug = '-'.join(job_title_words[:7])

    s1_template_html = job_detail_page(seoslug, str(vacancy['_id']))

    return s1_template_html


@app.route('/job/<string:seourl>-<string:vacancy_id_ext>')
def job_detail_page(seourl, vacancy_id_ext):
    """Allows a user to see a job detail"""
    path = '/job/{slug}-{ext}'.format(slug=seourl.encode('utf8'), ext=str(vacancy_id_ext.encode('utf8')))

    # ensure the path is correct for this job & redirect if not.
    try:
        # force lowercase path so we find the job -- it'll redirect if necessary to the correct url
        vacancy = x1vacancy.x1vacancy(job_url=path.lower())
    except StandardError as e:
        print e
        send_devs_email('Loading Job details page error', path)
        abort(500, e)
    if vacancy is None:
        abort(404)

    if vacancy is not None and path[0:len(vacancy['url'])] != vacancy['url']:  # also catches case-
        return redirect(
            '{proto}://{dom}{job}'.format(
                proto='https',  # request.environ['x1httporhttps'],
                dom=request.environ['x1domainname'],
                job=vacancy['url']),
            code=301)

    vacancy = x1vacancy.add_data_layer_data(vacancy)
    # jobs that expired more than 30 days ago get redirect to a core_skill search
    if 'job_is_expired' not in vacancy or vacancy['job_is_expired'] is True:
        zeroday = datetime.datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
        if 'last_live' not in vacancy or vacancy.get('last_live', 0) < (zeroday - datetime.timedelta(days=30)):
            return redirect(
                '{proto}://{dom}/jobs/?JobTypeCodeList={cs}'.format(
                    proto='https',  # request.environ['x1httporhttps'],
                    dom=request.environ['x1domainname'],
                    cs=vacancy['JobTypeCodeList']),
                code=301)

    try:
        user = x1_user_loader(current_user.id)
        cv_list = user.get('cvs')
    except StandardError:
        cv_list = None

    try:
        session['total_job_views'] += 1
    except KeyError:
        session['total_job_views'] = 1

    additional_flags = {}

    try:
        if not current_user.is_anonymous:
            db_session = x1cursor.mysql_session()
            user = _get(tables.User, session=db_session, email=current_user.email, cacheable=False)
            if user == None:
                raise StandardError("User Sync Error Between Mongo and MySQL")
            query = db_session.query(tables.UserStoredJob)
            query = query.filter_by(user_id=user.id, job_id=vacancy['_id'], status='live')
            query = query.first()
            if query:
                additional_flags['alreadySaved'] = query.to_dict()
    except StandardError as e:
        print e

    try:
        if not current_user.is_anonymous:
            db_session = x1cursor.mysql_session()
            query = db_session.query(tables.JobApplication)
            query = query.join(tables.Job)
            query = query.filter_by(id=vacancy['_id'])
            query = query.join(tables.JobApplication.user)
            query = query.filter_by(mongo_id=current_user.id)
            already_applied = query.first()
            if already_applied:
                already_applied.to_dict()
            else:
                already_applied = False
        else:
            already_applied = False
    except StandardError:
        additional_flags['_fail_alreadyApplied'] = str(sys.exc_info())
        already_applied = None
    else:
        if already_applied is not None:
            additional_flags['alreadyApplied'] = already_applied

    #XS-2510 - if the user has landed on a job detail page from Appcast we need their IP
    try:
        user_ip = user.current_login_ip
    except StandardError:
        user_ip = request.environ.get('HTTP_X_REAL_IP', request.remote_addr)

    setattr(g, '_user_ip', user_ip)
    template_html = x1jobdetail.get_job_detail(vacancy=vacancy,
                                               user_cvs=cv_list,
                                               enabled_websites=enabled_websites(),
                                               additional_flags=additional_flags,
                                               user=current_user)

    return template_html


@app.route('/typeahead/<string:fieldname>')
def typeahead_suggestion(fieldname):
    """Returns typeahead values"""
    fewchars = request.args.get('q')

    if fewchars is None or fewchars == '':
        return '[]'

    if fewchars == '_':
        # Allow the webservice style request for the full list of locations or core skills
        if fieldname in ['location', 'core_skill']:
            fewchars = ''

    if fieldname == "job_title":
        typeahead_json = get_job_title_typeahead(fewchars, region=request.environ['x1sitename'])
    elif fieldname == "core_skill":
        typeahead_json = get_coreskill_specialism_typeahead(fewchars, region=request.environ['x1sitename'])
    elif fieldname == "location":
        typeahead_json = get_location_typeahead(fewchars, region=request.environ['x1sitename'])
    return flask.Response(json.dumps(typeahead_json, default=str), status=200, mimetype='application/json')


@app.route('/<regex("(application-history|account-setup|saved-jobs|my-((career-)?profile|cvs|job-alerts))|recruiter-enquiries"):pagewanted>'
          )
@login_required
def my_account_pages(pagewanted):
    """Allows user to see their account pages"""
    kwargs = {'env': request.environ, 'enabled_websites': enabled_websites()}

    try:
        html = render_template('my-account/{filename}.html'.format(filename=pagewanted), **kwargs)
    except StandardError:
        if x1utils.dev_server():
            html = "Sorry, template error: {e}".format(e=str(sys.exc_info()))
        else:
            html = r'<!--fail-->'

    return html


@app.route('/user', methods=['GET', 'POST'])
@login_required
def update_current_user():
    """Allows a user to update their details"""
    if request.method == 'GET':
        current = {"name": current_user.name, "email": current_user.email}
        current['token'] = generate_auth_token(user=current_user, params=current, expires=1859)
        return jsonify(current)

    elif request.method == 'POST':
        try:
            req = request.get_json()
        except StandardError:
            abort(400)

        try:
            valid_token = decrypt_token(req.get('token'))
        except StandardError:
            abort(400, 'Token validation error')

        try:
            name = req.get('name')
        except StandardError:
            name = None

        try:
            _email = req.get('email')
        except StandardError:
            _email = None

        if _email is not None and bool(
                len(_email)) and _email != current_user.email and current_user.email == valid_token['params']['email']:
            new_email_already_exists = DBM.get_collection('user').find_one({"email": _email})
            if new_email_already_exists is not None:
                abort(422)

            try:
                DBM.get_collection('user').update_one({"_id": ObjectId(current_user.id)}, {'$set': {"email": _email}})
            except StandardError:
                abort(500)
            else:
                update_sql_user(email_address=_email)

        if name is not None and bool(len(name)) and name != current_user.name and current_user.name == valid_token['params']['name']:
            try:
                DBM.get_collection('user').update_one({"_id": ObjectId(current_user.id)}, {'$set': {"name": name}})
            except StandardError:
                abort(500)
            else:
                update_sql_user(name=name)

        new_you = x1_user_loader(current_user.id)
        return jsonify({"name": new_you.get('name'), "email": new_you.get('email')})


def update_sql_user(name=None, email_address=None):
    """Update the sql user when the Mongo user is updated"""
    db_session = x1cursor.mysql_session()
    sql_user = db_session.query(tables.User).filter_by(mongo_id=current_user.id).one_or_none()
    if sql_user:
        if name:
            sql_user.name = name
            try:
                sql_user.first_name = name.split(' ', 1)[0]
            except StandardError:
                sql_user.first_name = name
            try:
                sql_user.last_name = name.split(' ', 1)[1]
            except StandardError:
                pass
        if email_address:
            sql_user.email = email_address
        db_session.add(sql_user)
        db_session.flush()
    return


@app.route('/close-account', methods=['GET', 'POST'])
@fresh_login_required
def close_account():
    """Allows a user to close their account"""
    if request.method == 'GET':
        myvars = {'env': request.environ, 'enabled_websites': enabled_websites()}
        return render_template('my-account/close-account.html', **myvars)
    else:  # POST -- remove the user account
        x1cursor.mongo().get_database(config.get('mongo', 'database')).\
            get_collection('user').\
            update_one({"_id": current_user.id,
                        # restricting to active users only ensures
                        # that you can only close your account once
                        "active": True},
                       {"$set": {"active": False,
                                 "deleted_at": datetime.datetime.now(),
                                 # we also update the email address
                                 # to something unusable, so that:
                                 # attempts to log in come back 'user
                                 # unknown' rather than 'account
                                 # disabled'; so that we know who
                                 # unsubscribed; so that future
                                 # registrations for the same email
                                 # address will work ok; and so that
                                 # those future ones can still be
                                 # closed ok without uniqueness constraints
                                 "email": "{dt} - {e}".format(dt=datetime.datetime.now().isoformat(),
                                                              e=current_user.email)}})

        db_session = x1cursor.mysql_session()
        sql_user = load_user(_id=str(current_user.id), session=db_session)
        sql_user.active = 0
        sql_user.email = (datetime.datetime.now().isoformat() + sql_user.email)
        db_session.add(sql_user)
        alert_sql = db_session.query(tables.JobAlert).filter_by(user_id=sql_user.id).all()
        for alert in alert_sql:
            alert._deleted = datetime.datetime.now()
            db_session.add(alert)

        db_session.flush()
        delete_from_elastic(sql_user.id)

        logout_user()

        protocol = request.environ['x1httporhttps']
        domain = request.environ['x1domainname']

        if x1utils.dev_server():
            protocol = 'http'
            domain = re.sub(r'^www\.(.+)\.com', r'dev.\1.com:8888', domain)

        url = '{h}://{d}{u}'.format(h=protocol, d=domain, u='/')

        return redirect(url)


# static file handler for the dev server only, for use in debug
# mode. (the production server handles these via nginx)
if x1utils.dev_server():

    @app.route('/ui/<path:path>')
    def send_ui(path):
        return send_from_directory('DOCUMENT_ROOT/ui', path)

    @app.route('/favicon.ico')
    def send_favicon():
        return send_from_directory('DOCUMENT_ROOT', 'favicon.ico')

    @app.route('/robots.txt')
    def send_robotstxt():
        return send_from_directory('DOCUMENT_ROOT', 'robots.txt')

    @app.route('/session')
    def view_session():
        """Allows a dev to see and clear their redis session"""
        if 'clear_session' in request.args:
            for key in session.keys():
                del session[key]
        session_dict = {}
        for key, value in session.items():
            session_dict[key] = str(value)

        return jsonify(session_dict)


@app.route('/rms<regex("(.+)"):removesearchtoken>')
def deactivate_search(removesearchtoken):
    """Allow anonymous users to deactivate simple alerts"""
    db_session = x1cursor.mysql_session()
    try:
        data = decrypt_token(removesearchtoken)
        search_id = data['params']['search_id']
    except StandardError:
        return abort(404)

    try:
        query = db_session.query(tables.JobAlert).filter_by(id=search_id).first()
        if query:
            query._deleted = datetime.datetime.now()
            db_session.add(query)
            db_session.flush()
    except StandardError:
        pass
    kwargs = {'env': request.environ, 'request': request, 'enabled_websites': enabled_websites()}

    try:
        html = render_template('deactivate.html', **kwargs)
    except StandardError:
        protocol = request.environ['x1httporhttps']
        domain = request.environ['x1domainname']

        if x1utils.dev_server():
            protocol = 'http'
            domain = re.sub(r'^www\.(.+)\.com', r'dev.\1.com:8888', domain)

        url = '{h}://{d}'.format(h=protocol, d=domain)
        return redirect(url, code=302)
    return html


@app.route('/upgrade_paj_account', methods=['POST'])
def upgrade_paj_account():
    if current_user.is_anonymous:
        abort(403, 'User must login first')
    upgrade_json = request.get_json()
    if 'company_name' not in upgrade_json or not upgrade_json['company_name']:
        abort(422, 'No company name supplied')
    db_session = x1cursor.mysql_session()
    db_session.begin()
    new_company_urn = "PAJ-{0}".format(generate_etag())[:36]  #company_urn's are only 36 characters long, done to stop warnings on insertion
    new_company = tables.Company(company_name=upgrade_json.pop('company_name'),
                                 creation_datetime=datetime.datetime.now(),
                                 company_urn=new_company_urn)
    live_status = db_session.query(tables.AccountStatus).filter_by(account_status='live').first().account_status_id
    new_company.account_status_id = live_status
    new_company.company_type_id = 2
    db_session.add(new_company)
    db_session.flush()
    sql_user = load_user(_id=str(current_user.id), session=db_session)
    paj_role = db_session.query(tables.Role).filter_by(name='PAJ').first()
    if paj_role in sql_user.roles:
        db_session.rollback()
        abort(409, 'User is already a paj user')
    role_link = _get_or_create(tables.UserRoleCompany,
                               session=db_session,
                               user_id=sql_user.id,
                               role_id=paj_role.id,
                               company_id=new_company.company_id)
    sql_user.roles_association.append(role_link)
    db_session.add(sql_user)
    db_session.flush()
    db_session.commit()
    send_paj_welcome_email(sql_user)
    token = sso_login_serializer.dumps({"email": current_user.email})
    return jsonify({
        'status': 200,
        'statusText': 'OK',
        'sso_token': token,
        'sso_url': x1utils._get_recruiter_url(fragment='/login_sso', external=True)
    })


@app.route('/api/v1/Location')
def old_location_route():
    """Reroute any location queries to the new SQL endpoint"""
    query = unescapeurl(request.query_string)
    total_query = query
    split_query = query.split("&")
    query = split_query[0]
    self_data = {}
    db_session = x1cursor.mysql_session()
    try:
        if '$regex' in query:
            query_list = query.split('where=')[1].split(',')[0].replace("}", "").replace("{", "").replace('"', "").split(":")
            query_dict = {query_list[0]: query_list[2].replace('^', '')}
        else:
            query_list = query.split('where=')[1].replace("}", "").replace("{", "").replace('"', "").split(":")
            query_dict = dict(zip(query_list[::2], query_list[1::2]))
    except StandardError:
        query_dict = ''

    if 'max_results' in total_query:
        temp = total_query.split('max_results=')[1]
        max_results = temp.split('&')[0]
    else:
        max_results = 20

    if 'page' in total_query:
        temp = total_query.split('page=')[1]
        page = temp.split('&')[0]
    else:
        page = 1

    if 'projection' in total_query:
        temp = total_query.split('projection=')[1]
        projection = temp.split('&')[0]

    search_query = db_session.query(tables.Location)
    if "name1" in total_query:
        search_query = search_query.filter_by(name1=query_dict['name1'])
    search_query = search_query.join(tables.PostcodeMap)
    search_query = search_query.join(tables.PostcodeDistrict)
    if "postcode" in total_query:
        search_query = search_query.filter_by(postcode_district=query_dict['postcode_district'])
    search_query = search_query.join(tables.Region)
    if "region" in total_query:
        search_query = search_query.filter_by(region=query_dict['region'])
    search_query = search_query.join(tables.Country)
    search_query = search_query.order_by(tables.Location.label)
    search_query = search_query.with_entities(tables.Location.label, tables.PostcodeDistrict.postcode_district,
                                              tables.Region.website_region, tables.Location.name1, tables.Country.country)
    search_query = search_query.limit(max_results)

    if 'page' in total_query:
        offset = (int(page) - 1) * max_results
        if not offset:
            offset = 0
        search_query = search_query.offset(offset)

    return_list = []
    for i in search_query.all():
        temp = {}
        if 'projection' in total_query:
            if 'website_region' in projection:
                temp['website_region'] = i[2]
        else:
            temp['label'] = i[0]
            temp['postcode_district'] = i[1]
            temp['website_region'] = i[2]
            temp['name1'] = i[3]
            temp['country'] = i[4]
        return_list.append(temp)

    self_data['self'] = {}

    if "postcode" in total_query:
        meta_data = {"page": 1, "max_results": len(return_list)}
        self_data['self']['title'] = 'Location'
    elif "name1" in total_query:
        meta_data = {}
        meta_data["total"] = meta_data['max_results'] = len(return_list)
        meta_data['page'] = 1
        self_data['self']['href'] = "Location" if not total_query else "Location?{0}".format(total_query)
        self_data['self']['title'] = 'Location'
    else:
        self_data = {}
        meta_data = {}

    return jsonify(_items=return_list, _links=self_data, _meta=meta_data)


@app.route('/__ok', methods=['GET'])
def serverokcheck():
    return Response('ok', mimetype='text/plain')
